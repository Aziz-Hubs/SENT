# **SENTguard – Endpoint Detection & Response (EDR)**

**Division:** SENTsec (Security)  
**Architecture:** Endpoint Agent Extension (Go + Gopacket)  
**Status:** Endpoint Defense

## **1. Executive Summary**
SENTguard is the shield on the device. It acts as an Endpoint Detection and Response (EDR) / Next-Gen Antivirus (NGAV) system. Unlike the passive monitoring of SENTpulse, SENTguard is active defense—hooking into the OS kernel to block malicious processes, ransomware encryption attempts, and unauthorized network connections.

## **2. Technical Architecture**

### **2.1 The Defender**
*   **Kernel Integration:** Utilizes kernel drivers (Sysmon / eBPF on Linux) for deep visibility.
*   **Engine:** **Gopacket** for local packet inspection and process tree analysis.

## **3. Core Features**

### **3.1 Active Protection**
*   **Process Blocking:** Prevents execution of unsigned or blacklisted binaries.
*   **Ransomware Canary:** Monitors "Honeypot" files. If a process tries to modify them, the process is instantly killed and the device isolated.
*   **USB Control:** Blocks or Read-Only mounts unauthorized USB storage devices.

### **3.2 Investigation**
*   **Flight Recorder:** continuous recording of process executions, file mods, and network conns (stored locally, metadata sent to Cloud).
*   **Live Shell:** Secure remote shell for analysts to perform forensic cleanup.

### **3.3 Isolation**
*   **Network Quarantine:** Can cut off all network access except to the SENT management server, preventing lateral movement.

## **4. Integration with SENT Ecosystem**
*   **SENTpulse:** Deploys and manages the SENTguard module.
*   **SENTradar:** Streams EDR telemetry to the SIEM.
*   **SENTsignal:** Consumes hash blocklists to stop known malware.

## **6. Expanded Integration Scenarios**
*   **SENTnexus:** "Application Inventory". Builds a list of every installed app and its usage frequency for the documentation.
*   **SENTreflex:** "Automatic Isolation". If SENTguard detects high-confidence ransomware, it tells Reflex, which then tells the Firewall (SENTgrid) to block the device at the switch port level too (double-tap).
*   **SENTpilot:** "User Prompt". When blocking a file, pop up a dialog asking the user "Do you need this for work?" - creates a ticket for whitelisting if they say Yes.
*   **SENTmind:** "Education". If a user tries to run a known PIRATED game/app, show a SENTmind warning about software piracy risks.

## **7. Future Feature Roadmap**
*   **Rollback:** Shadow Copy integration to restore files encrypted by ransomware automatically.
*   **Memory Scanning:** Scan RAM for code injection (DLL sideloading, Cobalt Strike beacons).
*   **Linux eBPF:** High-performance, safe kernel tracing for Linux servers.
*   **MacOS System Extension:** Native Endpoint Security Framework support for Mac.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Process visibility and simple hash blocking.
*   **In-Scope:**
    *   Process Monitor (Log every process start/stop).
    *   Hash Blocker (Prevent execution of SHA256 list).
    *   Isolation Mode (Disconnect NIC).
    *   File Integrity Monitor (Watch critical folders).
*   **Out-of-Scope (Phase 2):**
    *   Ransomware Heuristics.
    *   Kernel Drivers.
    *   USB Control.
    *   Flight Recorder (Data Recorder).