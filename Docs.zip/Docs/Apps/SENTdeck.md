# **SENTdeck – Presentations**

**Division:** SENTerp (Business)  
**Architecture:** Canvas / Slide Engine  
**Status:** Productivity

## **1. Executive Summary**
SENTdeck is the storytelling tool. It allows users to create professional slide decks for sales pitches, internal reviews, and client reports. It focuses on "Smart Slides" that update automatically when underlying data changes.

## **2. Technical Architecture**

### **2.1 The Canvas**
*   **Rendering:** SVG-based canvas for scalable graphics.
*   **Templates:** Corporate branding lock (fonts, colors, logos) enforced globally.

## **3. Core Features**

### **3.1 Smart Slides**
*   **Live Data:** Link a chart in a slide to a SENTsheet cell or a SENTprism dashboard. When the data updates, the slide updates.
*   **Code Mode:** Markdown-to-Slide conversion for developers.

### **3.2 Presenter Mode**
*   **Remote Control:** Control the presentation from the SENT mobile app.
*   **Notes:** Private speaker notes.

## **4. Integration with SENT Ecosystem**
*   **SENThorizon:** QBR reports are generated as Deck files.
*   **SENTorbit:** Sales pitch decks are tracked (who opened it, how long they read) when sent to leads.

## **6. Expanded Integration Scenarios**
*   **SENTmeet:** "Native Broadcast". The deck engine renders directly into the video stream for pixel-perfect quality.
*   **SENTcanvas:** "Web Embed". Embed a deck into the corporate website (e.g., for an investor relations page).
*   **SENTpilot:** "Incident Review". Auto-generate a slide deck post-incident with timeline, root cause, and remediation steps.
*   **SENTvault:** Decks are stored with version control, allowing "Revert to yesterday's version".

## **7. Future Feature Roadmap**
*   **AI Design:** "Make this look better". Auto-arranges text and images into a professional layout.
*   **Live Q&A:** Spectators can type questions that appear on the presenter's private screen.
*   **Video Export:** Convert the presentation (with voiceover) into an MP4 video.
*   **Brand Enforcer:** Prevent users from using Comic Sans or non-brand colors.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Create a slide deck and present it.
*   **In-Scope:**
    *   Slide Editor (Text, Image, Shapes).
    *   Basic Transitions (Fade, Slide).
    *   Fullscreen Presenter Mode.
    *   PDF Export.
    *   Local Save.
*   **Out-of-Scope (Phase 2):**
    *   Live Data Links.
    *   Remote Control.
    *   Collaboration.
    *   Markdown Mode.