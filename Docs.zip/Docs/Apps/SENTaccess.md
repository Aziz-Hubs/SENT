# **SENTaccess – Client Portal**

**Division:** SENTerp (Business)  
**Architecture:** PWA (Progressive Web App)  
**Status:** Customer Experience

## **1. Executive Summary**
SENTaccess is the window for the customer. It is a unified web portal where external clients log in to interact with the business. It aggregates data from all other SENT apps into a customer-facing view.

## **2. Technical Architecture**

### **2.1 The Gateway**
*   **Security:** Rigid Role-Based Access Control (RBAC) to ensure clients only see their own data.
*   **Tech:** React-based PWA that can be installed on client mobile devices.

## **3. Core Features**

### **3.1 Self-Service**
*   **Support:** Create and view SENTpilot tickets.
*   **Billing:** View and pay SENTcapital invoices (Credit Card / Stripe integration).
*   **Approvals:** Approve SENTorbit quotes or SENTmission milestones.

### **3.2 Knowledge**
*   **Wiki:** Access public/shared articles from SENTnexus/SENTscribe.

## **4. Integration with SENT Ecosystem**
*   **All Apps:** It is essentially a "Read-Only" or "Limited-Write" view of the entire ecosystem.

## **6. Expanded Integration Scenarios**
*   **SENTsheet:** "Shared Reports". Clients can view specific SENTsheets shared with them (e.g., "Monthly Metrics").
*   **SENTvault:** "Data Room". Secure place to upload confidential documents during onboarding.
*   **SENTwave:** "Web Phone". Client can click "Call Support" to make a VoIP call directly from the browser.
*   **SENTpeople:** "Directory". Client can see a list of their account management team and their contact info.

## **7. Future Feature Roadmap**
*   **White Labeling:** Allow the MSP to put their own logo and domain (`portal.my-msp.com`).
*   **SSO:** Allow clients to login using their own Microsoft 365 or Google credentials.
*   **Push Notifications:** Send alerts to the client's phone (e.g., "Tech arriving in 5 mins").
*   **Custom Pages:** Allow the MSP to build custom pages using SENTcanvas logic inside the portal.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Client can view tickets and invoices.
*   **In-Scope:**
    *   Login/Logout.
    *   Ticket List (View/Create/Reply).
    *   Invoice List (View PDF).
    *   Profile Management (Change Password).
*   **Out-of-Scope (Phase 2):**
    *   Online Payments.
    *   Knowledge Base.
    *   Quote Approvals.
    *   Mobile PWA features.