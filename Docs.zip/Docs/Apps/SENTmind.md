# **SENTmind – Security Awareness Training**

**Division:** SENTsec (Security)  
**Architecture:** LMS & Phishing Sim (Gophish logic)  
**Status:** Human Defense

## **1. Executive Summary**
SENTmind targets the "Human Firewall". It is a Learning Management System (LMS) and Phishing Simulation platform designed to educate employees on security best practices. It tracks risk culture and identifies users who need remedial training.

## **2. Technical Architecture**

### **2.1 Phishing Engine**
*   **Sender:** Built-in SMTP engine (similar to **Gophish**) that can spoof internal headers (with permission).
*   **Tracking:** Unique tracking pixels and "click" links for each recipient.

### **2.2 Content Delivery**
*   **Player:** Video player embedded in the SENT desktop app for delivering training modules.

## **3. Core Features**

### **3.1 Simulation Campaigns**
*   **Templates:** Realistic email templates (e.g., "Password Expiry", "Urgent Invoice", "Package Delivery").
*   **Teachable Moments:** If a user clicks a phishing link, they are immediately redirected to a landing page explaining what they missed.

### **3.2 Education**
*   **Curriculum:** Video courses on Password Safety, Social Engineering, Physical Security, etc.
*   **Quizzes:** Interactive tests to verify knowledge retention.

### **3.3 Reporting**
*   **Risk Score:** User-level and Department-level risk scores based on click rates and training completion.

## **4. Integration with SENT Ecosystem**
*   **SENTshield:** Evidence of training compliance is automatically fed into GRC reports.
*   **SENTpeople:** Syncs employee lists to ensure all staff are enrolled in training.

## **6. Expanded Integration Scenarios**
*   **SENTpulse:** "Screensaver". Pushes "Security Tip of the Day" to the Windows Lock Screen/Screensaver via the agent.
*   **SENTradar:** "Real World Testing". If a user *actually* clicks a real malware link (detected by SIEM), SENTmind automatically enrolls them in remedial training.
*   **SENTchat:** "Bot Quiz". A chat bot occasionally asks a security question in the team channel. Correct answers earn points.
*   **SENTpolicy (Shield):** Users must pass a quiz on the "Acceptable Use Policy" before they can access the network (via SENTgrid NAC).

## **7. Future Feature Roadmap**
*   **USB Drop Sim:** Measure if users plug in unknown USB drives (requires SENTguard agent to detect).
*   **Smishing Sim:** Send fake SMS phishing texts (requires Twilio integration).
*   **Deepfake Training:** Examples of AI-generated voice/video to train users to spot fakes.
*   **Gamification Store:** Users earn "Coins" for training that can be redeemed for company swag.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Send a fake email and track clicks.
*   **In-Scope:**
    *   Email Sender (SMTP).
    *   Campaign Manager (Select Users, Select Template).
    *   Landing Page Server (The "You got caught" page).
    *   Basic Reporting (Sent vs. Clicked).
*   **Out-of-Scope (Phase 2):**
    *   LMS / Video Courses.
    *   Quizzes.
    *   Risk Scoring.