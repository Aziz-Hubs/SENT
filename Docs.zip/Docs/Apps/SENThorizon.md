# **SENThorizon – vCIO & Strategic Planning**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** Data Visualization & Reporting (React + Recharts)  
**Status:** Strategic Value Add

## **1. Executive Summary**
SENThorizon transforms the IT provider from a "fix-it" shop into a strategic partner. It is a Virtual CIO (vCIO) platform that visualizes technology roadmaps, budget forecasts, and risk assessments. It automates the preparation of Quarterly Business Reviews (QBRs), turning raw data from SENTpulse and SENTpilot into executive-level insights.

## **2. Technical Architecture**

### **2.1 The Presentation Layer**
*   **Engine:** React 19 optimized for print-layout CSS (for PDF generation).
*   **Visualization:** High-end charts and graphs using **Recharts**.

### **2.2 The Logic**
*   **Scoring Algorithms:** Proprietary algorithms to calculate "Infrastructure Health Scores" based on age, warranty status, and ticket volume.

## **3. Core Features**

### **3.1 Lifecycle Management**
*   **Warranty Tracking:** Automatic syncing of warranty expiration dates (Dell, Lenovo, HP APIs).
*   **Refresh Budgeting:** visualizes the "Budget Wall" – helping clients see upcoming capital expenses for hardware replacement.

### **3.2 Technology Roadmap**
*   **Gantt Charts:** Drag-and-drop interface for planning 1-year, 3-year, and 5-year technology initiatives (e.g., "Migrate to Cloud", "Upgrade Server").
*   **Recommendation Engine:** Suggests projects based on asset age or security gaps found by SENTprobe.

### **3.3 Report Generator**
*   **QBR Wizard:** Step-by-step wizard to build a QBR slide deck or PDF report.
*   **Executive Summary:** Auto-generates non-technical summaries of work performed, focusing on value (e.g., "We blocked 500 threats" vs "We installed patch KB123").

### **3.4 Compliance Dashboards**
*   **Standards:** Templates for NIST, HIPAA, and GDPR alignment (integrates with SENTshield data).

## **4. Integration with SENT Ecosystem**
*   **SENTpulse:** Sources hardware age and model data.
*   **SENTpilot:** Sources ticket volume data to identify "noisy" assets that need replacement.
*   **SENTdeck:** Exports roadmaps directly into presentation slides.

## **6. Expanded Integration Scenarios**
*   **SENTcapital (Finance):** Pulls "Spend Analysis" data. Compares this year's IT spend vs. last year's to show trends in the QBR.
*   **SENTorbit (CRM):** When a "Project Recommendation" is approved in SENThorizon, it automatically creates a "Deal" in SENTorbit for the sales team to close.
*   **SENTsurvey (Conceptual):** Ingests CSAT (Customer Satisfaction) scores to display a "User Sentiment" trend line alongside technical metrics.
*   **SENTcontrol (SaaS):** Imports "SaaS Utilization" data to show how much money the client is wasting on unused licenses.

## **7. Future Feature Roadmap**
*   **Hardware "Trade-In" Estimator:** Auto-calculate the residual value of old fleets to offset the cost of new hardware.
*   **Scenario Modeling:** "What If" sliders. "If we move to the cloud, our Capex drops by X but Opex rises by Y."
*   **Benchmarking:** Compare a client's "IT Health Score" against the average of all other clients in the same industry.
*   **Digital Sign-off:** Allow the client to digitally sign the roadmap during the meeting, freezing the plan.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Generate a PDF report summarizing Asset Age and Recommendations.
*   **In-Scope:**
    *   Dashboard showing Asset Age distribution ( <3 years, 3-5 years, >5 years).
    *   Manual Budget Entry (Input costs for future years).
    *   Basic PDF Export (Cover page + Charts).
    *   Simple Recommendations List (Title, Cost, Priority).
*   **Out-of-Scope (Phase 2):**
    *   Live Warranty API lookup.
    *   Interactive Presentation Mode.
    *   Comparison Benchmarking.