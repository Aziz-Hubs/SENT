# **SENTmarket – B2B Ecommerce**

**Division:** SENTerp (Business)  
**Architecture:** Storefront Generator  
**Status:** Commerce

## **1. Executive Summary**
SENTmarket is the storefront for the business. It allows companies to publish their SENTstock inventory to a public or private web portal for clients to place orders. It is ideal for B2B distributors and MSPs selling hardware.

## **2. Technical Architecture**

### **2.1 The Headless Core**
*   **API:** GraphQL API exposing products, pricing, and cart functionality.
*   **Frontend:** Next.js based template that renders the public store.

## **3. Core Features**

### **3.1 B2B Logic**
*   **Price Lists:** Client-specific pricing (e.g., "Gold Partners get 20% off").
*   **Approval Workflows:** "Junior Buyer" places order -> "Senior Manager" approves it.

### **3.2 Catalog**
*   **Rich Media:** Multiple images, datasheets (from SENTvault), and video demos.
*   **Bundles:** "New Hire Kit" (Laptop + Dock + Monitor).

## **4. Integration with SENT Ecosystem**
*   **SENTstock:** Real-time inventory availability.
*   **SENTorbit:** Orders are linked to the CRM deal history.
*   **SENTcapital:** Credit limits checked before allowing "Net 30" checkout.

## **6. Expanded Integration Scenarios**
*   **SENTwave:** "Click to Call". Support button on the store initiates a VoIP call to the sales team.
*   **SENTcanvas:** "Blog Products". Embed "Buy Now" buttons inside marketing blog posts.
*   **SENTpilot:** "RMA Portal". Clients can initiate a return for a purchased item directly from their order history.
*   **SENTbridge:** "Tax Included". Display prices including/excluding VAT based on the user's location.

## **7. Future Feature Roadmap**
*   **Configurator:** "Build your PC". A step-by-step wizard to build custom bundles.
*   **Subscription Selling:** Sell recurring services (like "Monthly Support") alongside hardware.
*   **Marketplace Mode:** Allow 3rd party vendors to list products on your store (Dropshipping).
*   **AI Recommendations:** "Customers who bought this also bought..."

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** List products and take orders.
*   **In-Scope:**
    *   Product Catalog (List/Grid).
    *   Cart & Checkout.
    *   Guest Checkout.
    *   Payment Gateway (Stripe).
    *   Order Confirmation Email.
*   **Out-of-Scope (Phase 2):**
    *   B2B Price Lists.
    *   Approval Workflows.
    *   Subscriptions.
    *   Configurator.