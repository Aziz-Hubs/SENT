# **SENTsonar – Network Detection & Response (NDR)**

**Division:** SENTsec (Security)  
**Architecture:** Packet Analysis (Suricata Wrapper)  
**Status:** Network Defense

## **1. Executive Summary**
SENTsonar provides deep visibility into network traffic. It is a Network Detection and Response (NDR) tool that sits on the wire (via port mirror or tap) and analyzes packet flows for malicious activity that logs might miss, such as Command & Control (C2) beacons or lateral movement.

## **2. Technical Architecture**

### **2.1 The Sensor**
*   **Engine:** **Suricata** (IDS/IPS engine) managed by a Go wrapper.
*   **Interface:** Promiscuous mode capture on designated network interfaces.

### **2.2 Analysis**
*   **Flow Logs:** Generates NetFlow/IPFIX equivalent data for bandwidth analysis.
*   **Signature Matching:** Uses Emerging Threats (ET) and custom Snort-syntax rules.

## **3. Core Features**

### **3.1 Intrusion Detection**
*   **Malware Communication:** Detects connections to known botnet controllers.
*   **Exploit Attempts:** Identifies signatures of attacks like EternalBlue or Log4Shell on the wire.

### **3.2 Traffic Analysis**
*   **Protocol Decoding:** Understands HTTP, DNS, TLS, SMB, etc.
*   **JA3 Fingerprinting:** Identifies malicious SSL/TLS clients based on their handshake fingerprint, even if traffic is encrypted.

### **3.3 File Extraction**
*   **Artifacts:** Can extract files (EXEs, PDFs) from the stream for analysis (sent to Sandbox).

## **4. Integration with SENT Ecosystem**
*   **SENTradar:** Sends alerts and flow logs to the SIEM.
*   **SENTreflex:** Can trigger firewall blocks via SENTgrid based on Sonar alerts.

## **6. Expanded Integration Scenarios**
*   **SENToptic:** "Bandwidth Hog". Identify which camera is saturating the network by correlating flow data with the camera IP.
*   **SENTguard:** "Confirmation". If Sonar sees C2 traffic, it asks SENTguard to check which process on the endpoint initiated that connection.
*   **SENTnexus:** "Unknown Device". If Sonar sees traffic from a MAC address not in the SENTnexus asset list, it creates a "Rogue Device" alert.
*   **SENTwave:** "VoIP Quality". Analyzes RTP streams to detect Jitter/Packet Loss without needing the phone's logs.

## **7. Future Feature Roadmap**
*   **Encrypted Traffic Analysis (ETA):** Machine Learning to detect malicious traffic inside SSL without decryption (based on packet timing/size).
*   **Decryption Broker:** Man-in-the-Middle capability to decrypt traffic (with installed root CA) for deep inspection.
*   **PCAP Replay:** Ability to upload a .pcap file and run it against the rules engine.
*   **Geo-Map:** 3D Globe visualization of where traffic is going.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Sniff traffic and log alerts.
*   **In-Scope:**
    *   Suricata Embedded.
    *   Interface Selector.
    *   ET Open Ruleset (Download & Update).
    *   Alert Log Viewer.
    *   Basic Stats (Packets/Sec).
*   **Out-of-Scope (Phase 2):**
    *   Flow Logging (NetFlow).
    *   File Extraction.
    *   JA3 Fingerprinting.