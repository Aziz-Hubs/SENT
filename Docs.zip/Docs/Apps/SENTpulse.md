# **SENTpulse – Remote Monitoring & Management (RMM)**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** Distributed Agent System (Go-Sysinfo + Wails)  
**Status:** Core Infrastructure Component

## **1. Executive Summary**
SENTpulse is the heartbeat of the SENTmsp division. It is a high-performance, low-latency Remote Monitoring and Management (RMM) platform designed to provide real-time visibility into the health and performance of servers, workstations, and network devices. Unlike traditional RMMs that rely on heavy Java or .NET agents, SENTpulse utilizes a lightweight, native Go binary that runs silently in the background with minimal resource overhead.

## **2. Technical Architecture**

### **2.1 The Agent (The Pulse)**
*   **Language:** Go (Golang) 1.24+
*   **Deployment:** Native binary service (Systemd on Linux, Windows Service on Windows, LaunchDaemon on macOS).
*   **Footprint:** <1% CPU usage, <20MB RAM idle.
*   **Communication:** Secure WebSocket (WSS) connection to the SENTcore central server.
*   **Telemetry Library:** `go-sysinfo` for hardware abstraction.

### **2.2 The Backend (The Heart)**
*   **Ingestion:** TimescaleDB (PostgreSQL Extension) for high-velocity metrics (CPU, RAM, Network I/O).
*   **Processing:** Real-time stream processing for alert triggering (e.g., "CPU > 90% for 5 mins").

### **2.3 The Frontend (The Monitor)**
*   **Framework:** React 19 + Wails v2.
*   **Visualization:** Real-time graphs using `Recharts` or `uPlot` for high-density time-series data.

## **3. Core Features**

### **3.1 Real-Time Telemetry**
*   **Hardware Monitoring:** Live streaming of CPU temperature, fan speeds, voltage, disk S.M.A.R.T status, and RAM utilization.
*   **Process Management:** Live task manager allowing the technician to kill runaway processes remotely without RDP.
*   **Service Control:** Start, stop, and restart system services (Windows Services / Systemd units).

### **3.2 Automated Self-Healing**
*   **Script Engine:** Built-in engine to execute remediation scripts (PowerShell, Bash, Python) triggered by specific alerts.
*   **Scenarios:** 
    *   *Scenario:* Print Spooler service crashes. -> *Action:* Restart Service.
    *   *Scenario:* Disk space < 5%. -> *Action:* Run cleanup script and clear temp folders.

### **3.3 Patch Management**
*   **OS Updates:** Windows Update API integration and Linux package manager (apt/dnf) wrapping.
*   **Third-Party Patching:** Integration with `winget` and `chocolatey` for keeping applications like Chrome, Zoom, and Adobe Reader up to date.

### **3.4 Remote Access**
*   **Terminal:** Secure, web-based SSH/PowerShell shell access.
*   **File Browser:** Remote file system navigation, upload, and download capabilities.

## **4. Data Strategy**
*   **Metric Storage:** All numerical telemetry is stored in **TimescaleDB** hypertables, partitioned by time and device ID.
*   **Retention:** Raw data kept for 7 days; 1-hour rollups kept for 1 year for trend analysis.

## **5. Integration with SENT Ecosystem**
*   **SENTpilot:** Automatically generates tickets when critical alerts (e.g., "Server Offline") are triggered.
*   **SENTnexus:** Updates asset data (RAM, CPU model, Serial Number) in the documentation wiki automatically.

## **6. Expanded Integration Scenarios**
*   **SENTpeople (HR):** Detects user login events and cross-references with "On Leave" status in SENTpeople. If an employee logs in while on vacation, an alert is triggered.
*   **SENTstock (Inventory):** When a hard drive fails (S.M.A.R.T error), SENTpulse checks SENTstock for compatible replacement drives in the local office inventory and reserves one.
*   **SENToptic (CCTV):** If a server goes offline unexpectedly, SENTpulse triggers SENToptic to bookmark the video feed of the server room at that exact timestamp to check for physical tampering.
*   **SENTreflex (SOAR):** Direct hook for advanced remediation. If SENTpulse detects ransomware behavior (mass file renames), it triggers a SENTreflex "Isolation Playbook" to cut network access.

## **7. Future Feature Roadmap**
*   **Advanced Power Management:** "Wake-on-LAN" proxying. Use one online agent in a subnet to wake up other offline agents for nightly patching.
*   **Software "Uninstall" Campaigns:** Ability to blacklist software (e.g., "Remove Spotify from all PCs"). The agent continuously checks for and uninstalls the target app.
*   **User Sentiment Tracking:** A "How is your IT?" smiley-face popup that appears after high-resource usage events to correlate system performance with user frustration.
*   **Offline Script Queuing:** Queue scripts for laptops that are currently offline; they execute immediately upon next reconnection.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Deploy an agent that can identify itself and execute a remote command.
*   **In-Scope:**
    *   Agent installer (Windows .exe).
    *   Heartbeat mechanism (Online/Offline status).
    *   Basic Hardware Info (Hostname, OS, IP, RAM Total).
    *   Remote Shell (CMD/PowerShell).
    *   Manual Script Execution (One-off).
*   **Out-of-Scope (Phase 2):**
    *   Patch Management.
    *   Automated Self-Healing triggers.
    *   Mac/Linux Agents.
    *   Remote File Browser.