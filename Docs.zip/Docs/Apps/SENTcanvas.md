# **SENTcanvas – Headless CMS & Website Builder**

**Division:** SENTerp (Business)  
**Architecture:** CMS Engine  
**Status:** Marketing

## **1. Executive Summary**
SENTcanvas empowers the Marketing team. It is a Headless Content Management System (CMS) used to build and manage the corporate website (e.g., sent.jo). It separates the content (text/images) from the code.

## **2. Technical Architecture**

### **2.1 Content Repository**
*   **Structure:** Flexible content types (Blog Post, Case Study, Team Member).
*   **Delivery:** High-performance JSON API.

## **3. Core Features**

### **3.1 Visual Editor**
*   **Page Builder:** "What You See Is What You Get" (WYSIWYG) editor for non-technical marketers.
*   **SEO:** Built-in tools for meta tags, sitemaps, and redirects.

### **3.2 Assets**
*   **Media Library:** Integrated with SENTvault for image optimization and serving.

## **4. Integration with SENT Ecosystem**
*   **SENTorbit:** "Contact Us" forms on the website inject leads directly into the CRM.
*   **SENTmarket:** Can embed products into blog posts.

## **6. Expanded Integration Scenarios**
*   **SENTpeople:** "Team Page". The "About Us" page automatically pulls team member bios and photos from HR (if marked public).
*   **SENTaccess:** "Login Link". Provides the authentication wrapper for the Client Portal.
*   **SENTchat:** "Live Chat". Embeds a SENTchat widget on the public site for visitors to talk to sales.
*   **SENThorizon:** "Public Status". Publish a "System Status" page (e.g., "All Systems Operational") powered by monitoring data.

## **7. Future Feature Roadmap**
*   **A/B Testing:** Serve two versions of a headline and see which converts better.
*   **Personalization:** Show different content if the visitor is an existing client vs. a prospect.
*   **Multi-Language:** Translation management workflow.
*   **Static Site Generator (SSG):** Compile the whole site to HTML for S3 hosting (faster/cheaper).

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Manage blog posts and basic pages.
*   **In-Scope:**
    *   Content Type Builder.
    *   Rich Text Editor.
    *   API Endpoint (Get /posts).
    *   Image Upload.
*   **Out-of-Scope (Phase 2):**
    *   Visual Page Builder.
    *   Preview Mode.
    *   SEO Tools.
    *   A/B Testing.