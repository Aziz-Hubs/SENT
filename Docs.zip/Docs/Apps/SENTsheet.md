# **SENTsheet – Collaborative Spreadsheets**

**Division:** SENTerp (Business)  
**Architecture:** Spreadsheet Engine (Univer)  
**Status:** Productivity

## **1. Executive Summary**
SENTsheet provides high-performance spreadsheets capable of handling complex financial modeling and data analysis. It supports standard Excel formulas and file formats (.xlsx) but adds real-time collaboration and database connectivity.

## **2. Technical Architecture**

### **2.1 The Engine**
*   **Core:** **Univer** (Open Source Office Engine) integrated into React.
*   **Calculation:** Local calculation for speed; server-side calculation for heavy datasets.

## **3. Core Features**

### **3.1 Compatibility**
*   **Excel:** Full import/export support.
*   **Formulas:** Supports 400+ standard functions (VLOOKUP, SUMIFS, etc.).

### **3.2 Data Connectivity**
*   **SQL Mode:** Pull data directly from the SENT Postgres database into a sheet for analysis. (e.g., `=SQL("SELECT * FROM tickets WHERE status='open'")`).

### **3.3 Visualization**
*   **Charts:** Pivot tables and charts generated from sheet data.

## **4. Integration with SENT Ecosystem**
*   **SENTcapital:** Export financial reports to Sheet for ad-hoc modeling.
*   **SENTorbit:** Bulk import/export of contacts.

## **6. Expanded Integration Scenarios**
*   **SENTprism:** "Data Source". A specific range in a Sheet can be defined as a data source for a Prism dashboard.
*   **SENTmission:** "Time Import". Upload a CSV/Sheet of timesheets to bulk-create entries in the project system.
*   **SENTstock:** "Stock Take". Warehouse staff fill out a Sheet on a tablet; a script syncs the counts back to the inventory database.
*   **SENTmail:** "Mail Merge". Use a Sheet as the recipient list for a mass email campaign.

## **7. Future Feature Roadmap**
*   **Python in Sheets:** Write Python code instead of Excel formulas for advanced data science (like Excel's Python integration).
*   **Forms:** Generate a web form that populates rows in the sheet.
*   **Version History:** Cell-level history (See who changed this specific cell and when).
*   **Macros:** TypeScript-based automation scripts.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Edit .xlsx files.
*   **In-Scope:**
    *   Univer Engine Integration.
    *   Basic Formulas (SUM, AVG).
    *   Cell Formatting (Color, Bold).
    *   Save/Load to SENTvault.
    *   CSV Import.
*   **Out-of-Scope (Phase 2):**
    *   SQL Connectivity.
    *   Real-time Collaboration.
    *   Charts / Pivot Tables.