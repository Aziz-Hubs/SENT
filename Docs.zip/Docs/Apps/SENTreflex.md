# **SENTreflex – SOAR & Automation**

**Division:** SENTsec (Security)  
**Architecture:** Job Queue (River) + Scripting  
**Status:** Security Automation

## **1. Executive Summary**
SENTreflex is the "Digital Responder" of the security division. It is a Security Orchestration, Automation, and Response (SOAR) platform. Its purpose is to execute pre-defined playbooks at machine speed to contain threats before a human analyst can even open a ticket.

## **2. Technical Architecture**

### **2.1 The Execution Engine**
*   **Queue:** **River** (Postgres-backed Job Queue for Go) for reliable, transactional task execution.
*   **Workers:** Isolated worker processes that execute Go plugins or scripts.

### **2.2 The Playbook Builder**
*   **UI:** Visual flowchart editor (React Flow) for designing logic (If -> Then -> Else).

## **3. Core Features**

### **3.1 Automated Containment**
*   **Account Lockout:** Connects to Active Directory / Azure AD to disable compromised users.
*   **Network Isolation:** Instructs SENTpulse/SENTguard to isolate a host from the network.
*   **Firewall Block:** Adds malicious IPs to the blocklist of perimeter firewalls via SENTgrid.

### **3.2 Enrichment**
*   **Intel Lookup:** Automatically queries VirusTotal, AbuseIPDB, and SENTsignal for reputation data on IPs/Hashes found in alerts.
*   **Context:** Fetches user details from SENTpeople (HR) to see if a "suspicious login" belongs to a VIP or a terminated employee.

### **3.3 Case Management Helpers**
*   **Communication:** Creates specific Slack/SENTchat channels for major incidents.
*   **Reporting:** Compiles timeline of automated actions for the post-incident report.

## **4. Integration with SENT Ecosystem**
*   **SENTradar:** The primary trigger for Reflex playbooks.
*   **SENTpilot (Sec):** Updates incident tickets with the results of automation (e.g., "User disabled successfully").

## **6. Expanded Integration Scenarios**
*   **SENTmail:** "Phishing Triage". If a user reports an email, Reflex parses the headers, checks the links, deletes the email from all inboxes if malicious, and notifies the user.
*   **SENTwave:** "Urgent Notification". If a Critical Severity incident occurs at 3 AM, Reflex triggers an automated phone call to the On-Call Engineer.
*   **SENTnexus:** "Credential Rotation". If a breach is suspected, Reflex forces a password reset on critical assets stored in the vault.
*   **SENTkiosk:** "Lockdown Mode". In a physical security event, Reflex locks SENTkiosk screens to prevent use.

## **7. Future Feature Roadmap**
*   **"Human in the Loop" Gates:** Pause execution and wait for an analyst to click "Approve" via SMS/Chat before taking destructive action (e.g., wiping a server).
*   **Playbook Marketplace:** Community-shared playbooks for common scenarios.
*   **Machine Learning Decisioning:** "Reflex AI" suggests the next step based on historical success rates.
*   **Multi-Tenant Orchestration:** Run a playbook across 50 different client environments simultaneously.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Trigger a script based on a Webhook.
*   **In-Scope:**
    *   Webhook Listener.
    *   Script Repository (Bash/Python).
    *   Job Queue.
    *   Execution Log (Success/Fail).
    *   Basic Email Notification.
*   **Out-of-Scope (Phase 2):**
    *   Visual Drag-and-Drop Builder.
    *   Wait/Pause Logic.
    *   External API Connectors (VirusTotal).