# **SENTprism – Business Intelligence (BI)**

**Division:** SENTerp (Business)  
**Architecture:** Analytics Engine (DuckDB / ClickHouse)  
**Status:** Intelligence

## **1. Executive Summary**
SENTprism converts data into decisions. It is a Business Intelligence platform that connects to all SENT apps (and external SQL sources) to provide cross-departmental dashboards. It replaces PowerBI or Tableau.

## **2. Technical Architecture**

### **2.1 The Query Engine**
*   **OLAP:** Utilizes embedded **DuckDB** for fast analytical queries on local data, or connects to ClickHouse for big data.
*   **Caching:** In-memory caching of query results.

## **3. Core Features**

### **3.1 Visualization**
*   **Dashboards:** Drag-and-drop canvas with 30+ widget types (Bar, Line, Pie, Map, KPI Card).
*   **Interactivity:** Drill-down capabilities (Click a bar -> see the underlying rows).

### **3.2 Data Modeling**
*   **ETL:** Light Extract-Transform-Load capabilities to join tables (e.g., Join "Sales" from SENTorbit with "Hours" from SENTmission).
*   **Calculated Fields:** Excel-like formulas for creating custom metrics.

### **3.3 Distribution**
*   **Alerts:** "Notify me via SENTchat if Monthly Revenue drops below $50k".
*   **Reports:** Scheduled email PDF exports.

## **4. Integration with SENT Ecosystem**
*   **SENTdeck:** Dashboards can be embedded live into presentation slides.
*   **SENTexec:** The "CEO Dashboard" is powered by Prism.

## **6. Expanded Integration Scenarios**
*   **SENTkiosk:** "Leaderboard". Display a sales leaderboard on a TV in the office.
*   **SENTpulse:** "NOC View". Aggregate stats from 10,000 agents into a global health map.
*   **SENTaccess:** "Client Reporting". Embed read-only dashboards into the client portal for transparency.
*   **SENTcapital:** "Budget vs Actual". Real-time gauge showing spending against the budget.

## **7. Future Feature Roadmap**
*   **Natural Language Query (NLQ):** "Show me sales by region for last month" -> Generates SQL.
*   **Mobile App:** Optimized view for viewing KPIs on the go.
*   **Data Marketplace:** Import public datasets (e.g., Census data, Weather history) to overlay on business data.
*   **Predictive Analytics:** Forecasting trend lines.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Visualize internal database queries.
*   **In-Scope:**
    *   Postgres Connector (Read-only).
    *   SQL Editor (Write query).
    *   Chart Library (Bar/Line/Table).
    *   Dashboard Canvas (Grid layout).
    *   Auto-refresh.
*   **Out-of-Scope (Phase 2):**
    *   Drag-and-Drop Query Builder (No-Code).
    *   External Data Sources (CSV/API).
    *   Drill-down.
    *   Alerting.