# **SENTscribe – Wiki & Knowledge Management**

**Division:** SENTerp (Business)  
**Architecture:** Rich Text Editor  
**Status:** Knowledge

## **1. Executive Summary**
SENTscribe is the corporate memory. It is a hierarchical document management system for creating Employee Handbooks, Standard Operating Procedures (SOPs), and Meeting Notes. It mimics the block-based editing experience of Notion.

## **2. Technical Architecture**

### **2.1 The Editor**
*   **Frontend:** Block-based editor (e.g., Editor.js or Tiptap customized).
*   **Format:** Stores data as structured JSON, not just HTML, allowing for dynamic content embedding.

## **3. Core Features**

### **3.1 Dynamic Content**
*   **Embeds:** Insert live data from other apps (e.g., a live chart from SENThorizon, a contact card from SENTorbit).
*   **Code Blocks:** Syntax highlighting for developers.

### **3.2 Organization**
*   **Hierarchy:** Infinite nesting of pages.
*   **Backlinks:** See what other pages link to the current page.

### **3.3 Collaboration**
*   **Multi-player:** Real-time co-editing (Google Docs style) using CRDTs (Conflict-free Replicated Data Types).
*   **Comments:** Inline commenting and task assignment.

## **4. Integration with SENT Ecosystem**
*   **SENTnexus:** The IT-specific documentation engine (Nexus) uses Scribe's editor core but adds structured asset fields.
*   **SENTmission:** Project specs are written in Scribe.

## **6. Expanded Integration Scenarios**
*   **SENTchat:** "Wiki Unfurl". Pasting a Scribe link in chat shows a preview of the content.
*   **SENTpeople:** "Policy Acknowledgement". Require users to scroll to the bottom of a Scribe page (e.g., "New HR Policy") and click "I Agree".
*   **SENTdeck:** "Convert to Slides". AI turns a structured Scribe document into a SENTdeck presentation.
*   **SENTmarket:** "Product Docs". Publish Scribe pages as public documentation for products sold in SENTmarket.

## **7. Future Feature Roadmap**
*   **AI Writer:** "Expand this paragraph" or "Change tone to professional".
*   **Database Tables:** Inline databases with filter/sort (Notion style).
*   **Offline Mode:** Edit documents without internet; syncs when back online.
*   **Template Gallery:** Community shared templates for Meeting Notes, PRDs, etc.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Create and edit hierarchical documents.
*   **In-Scope:**
    *   Rich Text Editor (Bold, Italic, H1-H3).
    *   Image Upload.
    *   Page Tree Structure (Sidebar).
    *   Read/Write Permissions.
    *   PDF Export.
*   **Out-of-Scope (Phase 2):**
    *   Real-time Co-editing.
    *   Live Embeds.
    *   Database Tables.