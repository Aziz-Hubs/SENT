# **SENTcal – Calendar & Scheduling**

**Division:** SENTerp (Business)  
**Architecture:** CalDAV Client  
**Status:** Scheduling

## **1. Executive Summary**
SENTcal is the master schedule. It handles personal agendas, team availability, and resource booking (conference rooms). It includes a built-in "Scheduling Link" feature (Calendly replacement) to allow external parties to book time without email back-and-forth.

## **2. Technical Architecture**

### **2.1 The Protocol**
*   **Standard:** CalDAV for syncing with Exchange, Google, and iCloud.
*   **Logic:** Conflict detection engine written in Go.

## **3. Core Features**

### **3.1 Calendar Views**
*   **Views:** Day, Week, Month, Year, and "Agenda" list.
*   **Overlay:** Toggle multiple calendars (Team, Personal, Holidays) to spot availability.

### **3.2 Booking System (Calendly Alt)**
*   **Public Links:** Generate `sent.link/user/15min` URLs.
*   **Rules:** Buffer times, maximum meetings per day, specific availability windows.

### **3.3 Resource Management**
*   **Room Booking:** Reserve physical spaces or equipment (Projectors, Cars).

## **4. Integration with SENT Ecosystem**
*   **SENTmeet:** Automatically generates video links for booked meetings.
*   **SENTpeople:** Tracks employee leave/vacation to block out calendars automatically.

## **6. Expanded Integration Scenarios**
*   **SENTmission:** "Project Timeline". Overlay project milestones and deadlines onto the main calendar view.
*   **SENTpilot:** "On-Call Schedule". Define who is on call for support tickets; SENTpilot uses this to route alerts.
*   **SENTcapital:** "Billable Events". Mark a calendar event as "Billable"; it flows to SENTcapital to generate an invoice.
*   **SENTkiosk:** "Room Display". Run SENTkiosk on a tablet outside a meeting room to show "Occupied until 2 PM" based on SENTcal data.

## **7. Future Feature Roadmap**
*   **Smart Scheduling:** "Find a Time". Analyze 5 people's calendars and suggest the best slot for a meeting.
*   **Travel Time:** Auto-add buffer time for travel if the location is physical (Google Maps integration).
*   **Weather:** Show weather forecast icons on the calendar days.
*   **Natural Language Entry:** Type "Lunch with Bob next Friday at noon" and it parses it correctly.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** View and Create events.
*   **In-Scope:**
    *   CalDAV Sync (Read/Write).
    *   Month/Week View.
    *   Event Creation (Title, Time, Description).
    *   Reminders (Notification).
*   **Out-of-Scope (Phase 2):**
    *   Public Booking Links.
    *   Room/Resource Booking.
    *   Smart Scheduling.