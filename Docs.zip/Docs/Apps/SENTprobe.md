# **SENTprobe – Vulnerability Scanner**

**Division:** SENTsec (Security)  
**Architecture:** Scanner Wrapper (Nuclei Engine)  
**Status:** Offensive Security

## **1. Executive Summary**
SENTprobe is the offensive security arm of the platform. It performs continuous vulnerability scanning to identify weaknesses before attackers do. Built on top of the powerful open-source **Nuclei** engine, it allows for template-based scanning of web applications, networks, and cloud infrastructure.

## **2. Technical Architecture**

### **2.1 The Scanning Core**
*   **Engine:** Embedded **Nuclei** (Go-based scanner).
*   **Templates:** Utilizes the community Nuclei-Templates repository + proprietary SENT signatures.

### **2.2 Scheduler**
*   **Routine:** Configurable scanning windows (e.g., "Scan External IPs every Sunday at 2 AM").

## **3. Core Features**

### **3.1 External Attack Surface Management (EASM)**
*   **Asset Discovery:** Subdomain enumeration and port scanning to find "Shadow IT".
*   **Vulnerability Checks:** Scans for CVEs, misconfigurations, default credentials, and exposed panels.

### **3.2 Internal Scanning**
*   **Agent-Based:** SENTpulse agents can act as "Scan Nodes" to scan the internal network from the inside, reaching non-public subnets.
*   **Authenticated Scans:** Supports credentialed scanning for deeper analysis.

### **3.3 Reporting**
*   **Prioritization:** Ranks vulnerabilities by CVSS score and "Exploitability" (is there a public exploit available?).
*   **Remediation Tips:** Provides clear instructions on how to fix findings.

## **4. Integration with SENT Ecosystem**
*   **SENTpilot (Sec):** Auto-creates tickets for High/Critical vulnerabilities.
*   **SENThorizon:** Feeds into the "Security Risk Score" for the vCIO reports.

## **6. Expanded Integration Scenarios**
*   **SENTcanvas (CMS):** "Pre-Flight Check". Automatically scans the corporate website staging environment before a new deployment is pushed live.
*   **SENTgrid:** "Router Audit". Scans network devices for open management ports (Telnet/HTTP) that should be closed.
*   **SENTcode (Conceptual):** Scans git repositories for accidental secrets/keys committed to code.
*   **SENTreflex:** "Auto-Patch". If SENTprobe finds a vulnerability that has a known patch, it triggers SENTreflex/SENTpulse to install the update.

## **7. Future Feature Roadmap**
*   **Fuzzing:** Active fuzzing of input fields to find SQL Injection/XSS (Advanced mode).
*   **Screenshotting:** Visual inspection of all open web ports.
*   **Technology Stack Fingerprinting:** Identify "Wordpress v5.8", "Nginx 1.14" to build a software inventory.
*   **Continuous Monitoring:** "Real-time" scanning. If a new subdomain appears, scan it immediately.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Run a Nuclei scan against a target URL.
*   **In-Scope:**
    *   Nuclei Binary Integration.
    *   Target Input Field.
    *   Default Template Set (Top 100 vulnerabilities).
    *   Result Parsing (JSON to Table).
    *   Export to CSV.
*   **Out-of-Scope (Phase 2):**
    *   Scheduler.
    *   Internal Agent-based scanning.
    *   Ticket integration.