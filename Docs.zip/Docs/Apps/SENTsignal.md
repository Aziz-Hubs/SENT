# **SENTsignal – Threat Intelligence Platform**

**Division:** SENTsec (Security)  
**Architecture:** Data Aggregator & Feeds  
**Status:** Intelligence

## **1. Executive Summary**
SENTsignal is the knowledge base of the enemy. It aggregates Threat Intelligence (TI) from open sources, commercial feeds, and the SENT community to provide context to security alerts. It ensures that the ecosystem is protected against the latest Indicators of Compromise (IoCs).

## **2. Technical Architecture**

### **2.1 The Aggregator**
*   **Format:** STIX/TAXII standards for exchanging threat info.
*   **Database:** Graph-based storage for linking Actors -> Tools -> IPs -> Hashes.

## **3. Core Features**

### **3.1 Feed Management**
*   **Sources:** Ingests data from AlienVault OTX, MISP, PhishTank, and proprietary SENT research.
*   **Confidence Scoring:** Algorithms to decay old indicators (e.g., an IP that was malicious 6 months ago might be safe now).

### **3.2 Ecosystem Sync**
*   **Blocklists:** Pushes "High Confidence" malicious IPs to SENTgrid (Firewalls) and SENTguard (Endpoints) for preemptive blocking.
*   **Retrospective Search:** When a new indicator is added, it triggers a search in SENTradar to see if *past* logs match the new threat.

## **4. Integration with SENT Ecosystem**
*   **SENTradar:** Enriches logs with reputation data.
*   **SENTreflex:** Used for automated decision making (e.g., "If reputation > 90/100, Block immediately").

## **6. Expanded Integration Scenarios**
*   **SENTmail:** "Spam Filter". Feeds malicious domains to the SENTmail server to block incoming spam.
*   **SENTprobe:** "Target List". If a new vulnerability is trending (e.g., in a specific VPN), SENTsignal tells SENTprobe to scan all clients for that specific CVE immediately.
*   **SENTaccess:** "Client Alert". Posts a "Security Advisory" to the client portal if a major global threat (like WannaCry) is active.
*   **SENTshield:** "Risk Assessment". Updates the risk register if a vendor used by the company is compromised (Supply Chain Intel).

## **7. Future Feature Roadmap**
*   **Dark Web Scraper:** Monitors underground forums for mentions of the company name.
*   **Brand Protection:** Detects typosquatting domains (e.g., `sent-support.com`) and issues takedown requests.
*   **TTP Mapping:** Maps indicators to the MITRE ATT&CK framework.
*   **Sharing Group:** Allow SENT users to anonymously share intel with each other (Community Defense).

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Aggregate simple IP/Domain blocklists.
*   **In-Scope:**
    *   Fetch feed from URL (TXT/CSV).
    *   Parse IP/Domain/Hash.
    *   Search UI (Check if IP is bad).
    *   API for other apps to query.
*   **Out-of-Scope (Phase 2):**
    *   STIX/TAXII support.
    *   Graph Database.
    *   Retrospective Search.