# **SENTshield – GRC & Compliance Manager**

**Division:** SENTsec (Security)  
**Architecture:** Policy Engine (Ent + Maroto PDF)  
**Status:** Governance & Compliance

## **1. Executive Summary**
SENTshield simplifies the complex world of Governance, Risk, and Compliance (GRC). It replaces spreadsheets and disjointed Word documents with a structured platform for managing compliance frameworks (ISO 27001, SOC 2, HIPAA, GDPR). It automates the evidence collection process, saving hundreds of hours during audits.

## **2. Technical Architecture**

### **2.1 The Policy Engine**
*   **Mapping:** Many-to-Many mapping of "Controls" to "Frameworks". (e.g., "Password Complexity" satisfies both NIST and ISO requirements).
*   **Evidence Linking:** Links "Proof" (screenshots, logs, configs) to specific controls.

### **2.2 The Document Generator**
*   **Engine:** **Maroto** (Go PDF Library).
*   **Output:** Generates pixel-perfect, watermarked PDF reports for auditors.

## **3. Core Features**

### **3.1 Framework Management**
*   **Pre-loaded Templates:** Comes with standard templates for NIST CSF, CIS Controls, HIPAA, GDPR, and PCI-DSS.
*   **Gap Analysis:** Visual dashboard showing compliance percentage (e.g., "78% compliant with SOC 2").

### **3.2 Automated Evidence Collection**
*   **Connectors:** Queries SENTpulse and SENTcontrol to automatically satisfy controls.
    *   *Control:* "All laptops must have encryption."
    *   *Check:* SENTshield queries SENTpulse -> "BitLocker Enabled on 100% of devices" -> *Status:* PASS.

### **3.3 Vendor Risk Management**
*   **Questionnaires:** Send digital assessment forms to 3rd party vendors.
*   **Scoring:** auto-calculates risk scores based on vendor responses.

### **3.4 Risk Register**
*   **Tracking:** Centralized registry of identified business risks, impact, probability, and mitigation plans.

## **4. Integration with SENT Ecosystem**
*   **SENTnexus:** Links policies to specific assets or departments.
*   **SENTmind:** Verifies that "Security Awareness Training" controls are met.

## **6. Expanded Integration Scenarios**
*   **SENTmission (Projects):** "Audit Project". Creates a project in SENTmission for the annual ISO audit, with tasks assigned to department heads.
*   **SENTscribe (Wiki):** Policies written in SENTshield are automatically published to the SENTscribe Employee Handbook as read-only pages.
*   **SENTpilot:** "Policy Violation". If a user violates a policy (e.g., installing banned software), a ticket is created and linked to the compliance record.
*   **SENTvault:** Stores the final signed Audit Reports securely with a "Legal Hold" retention policy.

## **7. Future Feature Roadmap**
*   **AI Policy Writer:** "Draft a BYOD policy for a healthcare company". The LLM generates the text.
*   **Evidence Expiration:** Alerts when manual evidence (e.g., a pen test report) is >1 year old and needs refreshing.
*   **Whistleblower Portal:** A secure, anonymous form for employees to report compliance violations.
*   **GDPR "Right to be Forgotten" Automation:** Orchestrates data deletion across all SENT apps when a request is received.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Manual Checklist for one framework (NIST).
*   **In-Scope:**
    *   Framework Import (CSV/JSON).
    *   Control List View.
    *   Status Toggling (Not Started / In Progress / Compliant).
    *   Manual Evidence Upload (File attachment).
    *   Risk Register (CRUD).
*   **Out-of-Scope (Phase 2):**
    *   Automated Evidence Collection.
    *   PDF Report Generation.
    *   Vendor Portals.