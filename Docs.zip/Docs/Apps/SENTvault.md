# **SENTvault – Document Management System (DMS)**

**Division:** SENTerp (Business)  
**Architecture:** File System Abstraction (Afero)  
**Status:** Storage

## **1. Executive Summary**
SENTvault is the secure digital filing cabinet. It replaces file servers, SharePoint, and Dropbox. It provides version-controlled, permission-based storage for all company documents.

## **2. Technical Architecture**

### **2.1 The Storage Layer**
*   **Engine:** **Afero** (Go FileSystem Abstraction).
*   **Backends:** Supports Local Disk (NAS), S3, Azure Blob, or MinIO.
*   **Deduplication:** Content-Addressable Storage (CAS) logic to avoid storing duplicate files.

## **3. Core Features**

### **3.1 File Operations**
*   **Versioning:** Automatic retention of file history (v1, v2, v3). Restore previous versions instantly.
*   **Locking:** "Check-Out" feature to prevent overwrite conflicts.
*   **Preview:** Server-side rendering of previews for 50+ file types (PDF, CAD, Office, Images).

### **3.2 Security**
*   **Permissions:** Granular ACLs (Read, Write, Delete, Share) at Folder and File level.
*   **Retention Policies:** Auto-delete files after X years (for GDPR) or "Legal Hold" to prevent deletion.

### **3.3 Search**
*   **OCR:** Optical Character Recognition on scanned PDFs and images makes them full-text searchable.

## **4. Integration with SENT Ecosystem**
*   **SENTmail:** Save attachments directly to Vault.
*   **SENTcapital:** Stores scanned invoices and receipts linked to ledger entries.

## **6. Expanded Integration Scenarios**
*   **SENTchat:** "File Stream". Dropping a file in chat actually uploads it to Vault and shares a link, preventing file duplication.
*   **SENTshield:** "DLP Scanning". Periodically scans Vault for sensitive data (Credit Cards, SSNs) stored in the wrong folders.
*   **SENTaccess:** "Client Share". Create a secure "Drop Zone" folder where clients can upload large files.
*   **SENTscribe:** "Media Host". Images embedded in Scribe wikis are actually stored and served from Vault.

## **7. Future Feature Roadmap**
*   **Digital Signatures:** "DocuSign" replacement. Add signature fields to PDFs.
*   **Auto-Tagging:** AI analyzes content and adds tags (e.g., "Invoice", "Contract", "Resume").
*   **Workflow:** "Approval Chain". File cannot be moved to "Approved" folder until Manager clicks Approve.
*   **Offline Sync:** Desktop client that syncs folders to local disk (Dropbox style).

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Store and Retrieve files.
*   **In-Scope:**
    *   Folder Structure (Tree View).
    *   Upload/Download.
    *   Basic Permissions (Public/Private).
    *   File Previews (Images/PDF).
    *   Recycle Bin.
*   **Out-of-Scope (Phase 2):**
    *   Versioning.
    *   OCR / Full-text Search.
    *   Sharing Links.
    *   Retention Policies.