# **SENTmeet – Video Conferencing**

**Division:** SENTerp (Business)  
**Architecture:** SFU / WebRTC (Pion)  
**Status:** Communication

## **1. Executive Summary**
SENTmeet is a secure, high-definition video conferencing platform. It eliminates the need for Zoom or Google Meet by providing a native meeting experience. It leverages the "Worker Mode" of the SENT binary to act as a Selective Forwarding Unit (SFU), routing video packets efficiently.

## **2. Technical Architecture**

### **2.1 The Media Server**
*   **Engine:** **Pion WebRTC** (Go).
*   **Topology:** SFU (Selective Forwarding Unit) – clients send 1 stream up, receive N streams down (optimized bandwidth).

## **3. Core Features**

### **3.1 Meeting Experience**
*   **HD Video:** Adaptive bitrate streaming (720p/1080p).
*   **Screen Sharing:** Share entire desktop or specific window (native OS capture).
*   **Recording:** Server-side or Client-side recording to MP4.

### **3.2 Collaboration**
*   **Whiteboard:** Collaborative drawing canvas.
*   **Breakout Rooms:** Split large meetings into smaller groups.

### **3.3 Privacy**
*   **E2EE:** End-to-End Encryption option for sensitive meetings.
*   **Lobby:** Waiting room controls.

## **4. Integration with SENT Ecosystem**
*   **SENTcal:** Meetings are automatically linked to calendar events.
*   **SENTchat:** "Join" button appears in chat channels when a meeting starts.

## **6. Expanded Integration Scenarios**
*   **SENTscribe:** "Meeting Minutes". The meeting audio is transcribed in real-time and saved as a SENTscribe document automatically.
*   **SENTorbit:** "Sales Call Analysis". Recordings are linked to the CRM deal; AI analyzes "Talk Time" ratio between Sales Rep and Client.
*   **SENTdeck:** "Live Presenter". Push slides from SENTdeck directly into the video stream (not just screen sharing) for higher quality text rendering.
*   **SENTpeople:** "Interview Mode". When interviewing a candidate, the HR scorecard appears in a side panel for the interviewer.

## **7. Future Feature Roadmap**
*   **Virtual Backgrounds:** Blur or replace background without a green screen.
*   **Noise Cancellation:** AI-based suppression of dog barking/keyboard typing.
*   **Remote Desktop Control:** Allow one participant to control another's mouse (for IT support).
*   **Live Polling:** Pop-up quizzes/polls during the meeting.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Multi-party video call.
*   **In-Scope:**
    *   Pion SFU Backend.
    *   Join via Link.
    *   Camera/Mic toggles.
    *   Grid View (Up to 4 people).
    *   Screen Sharing.
*   **Out-of-Scope (Phase 2):**
    *   Recording.
    *   Chat inside meeting.
    *   Virtual Backgrounds.
    *   Dial-in (Phone) support.