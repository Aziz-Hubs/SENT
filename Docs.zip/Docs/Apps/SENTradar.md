# **SENTradar – SIEM & Log Analysis**

**Division:** SENTsec (Security)  
**Architecture:** Log Aggregator (Go + Expr + Sigma)  
**Status:** Core Security Intelligence

## **1. Executive Summary**
SENTradar is the central nervous system of the SENTsec division. It is a Security Information and Event Management (SIEM) platform built for speed and simplicity. Unlike traditional SIEMs (Splunk, Elastic) that require massive clusters to query data, SENTradar uses a highly optimized Go-based ingestion engine and "Sigma" rules to detect threats in real-time with minimal latency.

## **2. Technical Architecture**

### **2.1 The Collector**
*   **Ingestion:** Acts as a Syslog server (UDP/TCP 514) and Windows Event Collector.
*   **Normalization:** Converts disparate log formats (JSON, CSV, raw text) into a unified "SENT Event Schema".

### **2.2 The Detection Engine**
*   **Logic:** Uses **Expr** (Expression Language for Go) to evaluate logs against detection rules.
*   **Standard:** Native support for **Sigma Rules** (Generic Signature Format for SIEM Systems), allowing immediate usage of thousands of open-source threat detection rules.

### **2.3 Data Store**
*   **Hot Storage:** TimescaleDB for recent logs (searchable < 10ms).
*   **Cold Storage:** Compressed Parquet files on S3/Local Disk for long-term compliance retention.

## **3. Core Features**

### **3.1 Real-Time Threat Detection**
*   **Correlation:** Detects patterns across multiple sources (e.g., "5 Failed Logins on Server A" + "Successful Admin Login on Server B").
*   **Rule Management:** Git-integrated rule repository. Pulls updates from the community Sigma repo automatically.

### **3.2 Forensic Search**
*   **Query Language:** A simplified SQL-like syntax for hunting (e.g., `user="admin" AND ip NOT IN (trusted_subnets)`).
*   **Timeline:** Interactive histogram showing event volume over time to identify spikes (DDoS, Brute Force).

### **3.3 Entity Behavior Analytics (UEBA)**
*   **Baselines:** Learns "normal" behavior (e.g., "User Bob logs in from London at 9 AM").
*   **Anomalies:** Flags deviations (e.g., "User Bob logged in from Pyongyang at 3 AM").

## **4. Integration with SENT Ecosystem**
*   **SENTreflex:** Triggers automated playbooks when high-severity alerts are fired.
*   **SENTpilot (Sec):** Creates a security incident ticket for analyst investigation.
*   **SENTpulse:** Deploys the log shipping agent to endpoints.

## **6. Expanded Integration Scenarios**
*   **SENTpeople (HR):** "Insider Threat". Correlates "Notice of Resignation" from HR with "Large File Download" events on the user's laptop.
*   **SENTgrid (Network):** Ingests firewall logs to match "Denied Traffic" spikes with "Endpoint Malware" events.
*   **SENTcontrol (SaaS):** Correlates "Impossible Travel" (Login from NY and Tokyo in 1 hour) across M365 and Local Windows Logins.
*   **SENToptic:** "Physical Correlation". If a "Door Forced Open" event is logged by access control, SENTradar pulls the camera log.

## **7. Future Feature Roadmap**
*   **AI Hunter:** An LLM-based assistant that can write queries for you (e.g., "Show me all logins from Russia last week").
*   **Dark Web Monitor:** Automatically search for company domain credentials in breached databases.
*   **Graph Visualizer:** A "Threat Graph" showing the attack path (User -> Phishing Email -> Malware -> C2 Server).
*   **Retro-Hunting:** When a new Rule is added, automatically re-scan the last 30 days of cold storage to see if we missed it.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Ingest logs and run simple keyword matches.
*   **In-Scope:**
    *   Syslog Listener (UDP 514).
    *   Basic Parser (JSON/Text).
    *   Log Storage (Postgres/Timescale).
    *   Search UI (Filter by Time, Host, Message).
    *   Basic Alerting (If message contains "Error", email Admin).
*   **Out-of-Scope (Phase 2):**
    *   Sigma Rule Engine.
    *   Correlation Logic.
    *   UEBA.
    *   Cold Storage Archiving.