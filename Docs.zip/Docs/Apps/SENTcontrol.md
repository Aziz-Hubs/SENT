# **SENTcontrol – SaaS Management Platform (SMP)**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** API Aggregator (Go Sync Engine)  
**Status:** Cloud Management

## **1. Executive Summary**
SENTcontrol provides command and control over the sprawling landscape of Cloud and SaaS applications. As companies move away from on-premise servers, SENTcontrol fills the gap by managing Microsoft 365, Google Workspace, Adobe, and other enterprise SaaS platforms via a single API-driven console.

## **2. Technical Architecture**

### **2.1 The Sync Engine**
*   **Connectors:** Modular Go interfaces for REST/Graph APIs (Microsoft Graph, Google Admin SDK, AWS IAM).
*   **Rate Limiting:** Intelligent queue management to handle API quotas and throttling from providers.

### **2.2 The Unified Identity Model**
*   **Mapping:** Maps disparate user identities (e.g., `j.doe@company.com` in M365 vs `john.doe@adobe.com`) to a single SENT "User Entity".

## **3. Core Features**

### **3.1 License Optimization**
*   **Waste Detection:** Identifies unassigned licenses or users who haven't logged in for 90+ days.
*   **Downgrade Recommendations:** Suggests moving users from E5 to E3 plans if they aren't utilizing premium features.

### **3.2 User Lifecycle Management**
*   **Onboarding:** "One-Click" provisioning – creates accounts in M365, Slack, and Zoom simultaneously.
*   **Offboarding:** "Kill Switch" – instantly revokes access, resets passwords, and converts email to shared mailbox across all connected SaaS apps.

### **3.3 Security Auditing**
*   **MFA Reporting:** Lists all users without Multi-Factor Authentication enabled.
*   **External Sharing:** Scans for files shared publicly or with external domains (Google Drive / OneDrive / SharePoint).

### **3.4 Tenant Management**
*   **Multi-Tenant View:** For MSPs, allows viewing all client M365 tenants in a single table without logging in and out of portals.

## **4. Integration with SENT Ecosystem**
*   **SENTpeople:** Triggers onboarding/offboarding workflows based on HR status changes.
*   **SENTnexus:** Stores SaaS configuration documentation and recovery keys.

## **6. Expanded Integration Scenarios**
*   **SENTcapital:** Matches "Billed License Count" from distributor invoices against "Active License Count" in SENTcontrol to find billing discrepancies.
*   **SENTshield (GRC):** Automated evidence collection for Cloud Security posture (e.g., verifying that "Do not allow public S3 buckets" is TRUE).
*   **SENTpilot:** Creates a ticket if "Global Admin" privileges are granted to a new user unexpectedly.
*   **SENTmind (Training):** Assigns specific training modules based on SaaS usage (e.g., Assign "Salesforce Security" training only to Salesforce users).

## **7. Future Feature Roadmap**
*   **"Shadow SaaS" Discovery:** Parse SENTgrid firewall logs to identify traffic to unknown SaaS apps (e.g., Dropbox, WeTransfer) that are not being managed.
*   **Configuration Drift:** "Golden Tenant" templates. Alert if a client's M365 Spam Filter settings deviate from the MSP's standard best practice.
*   **Self-Service License Request:** A portal for employees to request a license (e.g., "I need Adobe Pro"), which goes to a manager for approval before auto-provisioning.
*   **Email Signature Management:** Centralized control of email signatures across M365 and Google Workspace.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Read-only view of Microsoft 365 Users and Licenses.
*   **In-Scope:**
    *   Microsoft Graph API Integration (Client ID/Secret).
    *   User List (Name, Email, Assigned Licenses).
    *   License List (Total Purchased, Total Assigned).
    *   Basic MFA Status check (Enabled/Disabled).
*   **Out-of-Scope (Phase 2):**
    *   Writing data (Creating users/Changing passwords).
    *   Google/Adobe Integrations.
    *   Offboarding Workflows.