# **SENTwave – Cloud VoIP & Telephony**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** Real-time Communication (Pion WebRTC + SIP)  
**Status:** Communications Infrastructure

## **1. Executive Summary**
SENTwave is a modern, cloud-native Voice over IP (VoIP) phone system embedded directly into the SENT desktop experience. It replaces physical desk phones and legacy PBX systems with a softphone capable of handling calls, SMS, and complex routing logic. It leverages the "Native Bridge" pattern to ensure high-quality audio processing free from browser tab throttling.

## **2. Technical Architecture**

### **2.1 The Voice Engine**
*   **Library:** **Pion WebRTC** (Pure Go implementation) for media transport.
*   **Protocol:** SIP (Session Initiation Protocol) over WebSocket for signaling.
*   **Codecs:** Opus (high fidelity) and G.711 (legacy compatibility).

### **2.2 Infrastructure**
*   **Gateways:** Connects to upstream SIP Trunking providers (e.g., Twilio, Telnyx) for PSTN connectivity.

## **3. Core Features**

### **3.1 Unified Softphone**
*   **Dialer:** Integrated keypad and contact list within the SENT app.
*   **Call Handling:** Hold, Transfer (Blind & Attended), Mute, and Conference.
*   **Visual Voicemail:** Transcribed voicemail messages sent directly to the user's inbox (SENTmail) and chat (SENTchat).

### **3.2 Advanced Routing (PBX)**
*   **IVR Editor:** Visual "Drag-and-Drop" editor for building call menus (e.g., "Press 1 for Sales").
*   **Ring Groups:** Strategies for team ringing (Simultaneous, Round Robin, Least Recently Called).
*   **Time Conditions:** Automatic routing based on business hours and holidays.

### **3.3 Omni-Channel**
*   **SMS/MMS:** Send and receive text messages from business numbers.
*   **Fax:** Digital faxing (PDF to Fax / Fax to PDF).

### **3.4 Analytics**
*   **Heatmaps:** Visualizes call volume by hour/day to assist with staffing.
*   **Recording:** Automatic call recording and secure archiving for compliance.

## **4. Integration with SENT Ecosystem**
*   **SENTorbit:** "Screen Pop" – automatically opens the CRM record of the caller before the phone is answered.
*   **SENTchat:** Updates user status to "On a Call" automatically.
*   **SENTpilot:** Logs call details and recordings to client tickets for billable support calls.

## **6. Expanded Integration Scenarios**
*   **SENTcal:** "Do Not Disturb" sync. If SENTcal shows a meeting, SENTwave automatically routes calls to voicemail or a colleague.
*   **SENTpeople:** "Holiday Routing". If the receptionist is marked as "On Leave" in SENTpeople, call routing automatically bypasses them.
*   **SENTcapital:** Call Accounting. Automatically assigns costs to specific clients based on area codes or dedicated trunk usage.
*   **SENTkiosk:** "Intercom Mode". Can page a SENTkiosk device (e.g., in a warehouse) to announce a message.

## **7. Future Feature Roadmap**
*   **AI Voice Receptionist:** A conversational AI that answers the phone, understands intent ("I want to pay a bill"), and routes the call or sends a link.
*   **Sentiment Analysis (Voice):** Live sentiment scoring during the call. If the caller sounds angry, alert a manager to "Barge In" and help.
*   **Teams Integration:** Sip-forking to ring Microsoft Teams endpoints alongside SENTwave.
*   **Click-to-Call Browser Plugin:** Recognize phone numbers on any webpage and turn them into clickable links.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Make and Receive a 1:1 call to the PSTN.
*   **In-Scope:**
    *   SIP Registration to one provider (Twilio).
    *   Dialpad UI.
    *   Inbound Call notification (Ring).
    *   Active Call Controls (Mute, Hangup).
    *   Call History Log.
*   **Out-of-Scope (Phase 2):**
    *   IVR / Auto-Attendant.
    *   Call Transfers.
    *   Conference Calling.
    *   Voicemail Transcription.