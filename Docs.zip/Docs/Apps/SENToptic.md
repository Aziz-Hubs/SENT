# **SENToptic – CCTV & Physical Security**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** Streaming Media Server (MediaMTX + Pion)  
**Status:** Physical Security

## **1. Executive Summary**
SENToptic bridges the gap between digital and physical security. It is a Network Video Recorder (NVR) and surveillance viewing platform that aggregates streams from IP cameras (Hikvision, Axis, Dahua, ONVIF) into the SENT desktop app. It eliminates the need for clunky, insecure proprietary browser plugins often required by camera vendors.

## **2. Technical Architecture**

### **2.1 The Streaming Core**
*   **Engine:** **MediaMTX** (formerly rtsp-simple-server) embedded as a worker service.
*   **Protocols:** Ingests RTSP/RTMP; transmuxes to WebRTC for low-latency (<500ms) viewing in the frontend.
*   **Processing:** Hardware acceleration (ffmpeg bindings) for decoding/encoding streams.

### **2.2 Storage**
*   **Recording:** Continuous recording or Motion-Only recording to local disk or NAS.
*   **Format:** Standard MP4/MKV containers for easy export.

## **3. Core Features**

### **3.1 Live Matrix**
*   **Grid View:** Customizable layouts (2x2, 3x3, 1+5) for viewing multiple cameras simultaneously.
*   **PTZ Control:** Pan-Tilt-Zoom controls for supported cameras via ONVIF protocol.
*   **Two-Way Audio:** "Talk Down" feature allows operators to speak through camera speakers.

### **3.2 Smart Playback**
*   **Timeline:** Scrubbable timeline with visual markers for "Motion Events".
*   **Smart Search:** Ability to search for movement in a specific region of the frame (e.g., "Show me movement near the back door only").

### **3.3 AI Detection (Edge)**
*   **Object Detection:** Basic integration to classify objects (Person, Car, Truck) using lightweight local inference (if hardware permits) or camera-side metadata.

## **4. Integration with SENT Ecosystem**
*   **SENTnexus:** Maps cameras to physical floor plans.
*   **SENTpilot:** Generates a ticket if a camera goes offline or if a "loitering" alarm is triggered.
*   **SENTradar:** Logs physical access events (e.g., "Motion in Server Room") alongside digital access logs for forensic correlation.

## **6. Expanded Integration Scenarios**
*   **SENTkiosk:** "Security Mirror". Displays the live feed of the entrance camera on the SENTkiosk screen when not in use.
*   **SENTstock:** "Theft Investigation". Link timestamp of "Inventory Adjustment (Lost/Stolen)" to video footage of the warehouse at that time.
*   **SENTguard:** If SENTguard detects a "USB Injection Attack" on a reception PC, SENToptic automatically pops up the camera feed facing that desk.
*   **SENTaccess:** Allows clients to view their own office cameras via the web portal (with strict permission fencing).

## **7. Future Feature Roadmap**
*   **License Plate Recognition (LPR):** Native LPR to log vehicles entering the premises.
*   **Face Recognition:** Identify VIPs or blacklisted individuals.
*   **Heatmaps:** Retail analytics showing "Dwell Time" in specific store aisles.
*   **Dewarping:** Support for 360-degree Fisheye cameras.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** View live streams from RTSP cameras.
*   **In-Scope:**
    *   RTSP Ingest (Manual URL entry).
    *   WebRTC Transmuxing (Low latency view).
    *   4-Camera Grid Layout.
    *   Snapshot (Take picture).
*   **Out-of-Scope (Phase 2):**
    *   Recording / NVR capabilities.
    *   PTZ Controls.
    *   Motion Detection.
    *   Audio.