# **SENTchat – Team Messaging & Collaboration**

**Division:** SENTerp (Business)  
**Architecture:** Real-time Pub/Sub (Centrifugo)  
**Status:** Collaboration

## **1. Executive Summary**
SENTchat is the central hub for internal communication, designed to replace Slack or Microsoft Teams. It prioritizes asynchronous work with threaded conversations while supporting real-time urgency when needed. It is deeply embedded into every other SENT application, providing a "Chat Sidebar" everywhere.

## **2. Technical Architecture**

### **2.1 The Messaging Engine**
*   **Core:** **Centrifugo** (Go) for handling millions of WebSocket connections.
*   **Storage:** PostgreSQL for message history; Redis for presence and ephemeral state.

## **3. Core Features**

### **3.1 Structure**
*   **Channels:** Public (#general) and Private (Lock icon) rooms.
*   **Threads:** Sidebar discussions to keep main channels clean.
*   **DMs:** Direct Messages for 1:1 or small group privacy.

### **3.2 Rich Media**
*   **Snippets:** Code syntax highlighting.
*   **Voice/Video:** Instant "Huddle" buttons to start a SENTmeet session in the channel.

### **3.3 Workflow Automation**
*   **Bots:** Webhook integration for system alerts (e.g., "New Ticket #123").
*   **Slash Commands:** `/ticket create`, `/zoom`, `/gif`.

## **4. Integration with SENT Ecosystem**
*   **SENTpeople:** Shows Org Chart info on user profiles.
*   **SENTdrive:** Drag-and-drop file sharing links directly to the DMS.

## **6. Expanded Integration Scenarios**
*   **SENTpilot:** "Incident War Room". When a Priority 1 ticket is created, a temporary SENTchat channel is automatically created and relevant staff invited.
*   **SENTcal:** "Availability Status". User avatar shows "In a Meeting" or "On Vacation" automatically based on calendar.
*   **SENTprism:** "Data Unfurling". Pasting a link to a dashboard (e.g., `sent://prism/dashboard/sales`) renders a live mini-chart in the chat.
*   **SENTreflex:** "Approval Bot". Security automation asks "Block this IP?" in chat; Admin clicks "Yes" button in the message to execute.

## **7. Future Feature Roadmap**
*   **Audio Clips:** Walkie-Talkie style voice messages.
*   **Message Translation:** Real-time translation of messages for international teams.
*   **Guest Access:** Invite external clients to specific channels (Single Channel Guests).
*   **Global "Do Not Disturb":** Mutes notifications across all SENT apps (Mail, Pilot, Chat) simultaneously.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Real-time text chat.
*   **In-Scope:**
    *   WebSocket Connection (Centrifugo).
    *   Channel List.
    *   Message Sending/Receiving (Text only).
    *   Presence (Online/Offline).
    *   Notifications (System tray).
*   **Out-of-Scope (Phase 2):**
    *   Threads.
    *   File Uploads.
    *   Voice/Video Calls.
    *   Search History.