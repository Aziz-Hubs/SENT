# **SENTmail – Universal Email Client**

**Division:** SENTerp (Business)  
**Architecture:** IMAP/SMTP Client (Go-IMAP)  
**Status:** Communication

## **1. Executive Summary**
SENTmail is a lightning-fast, native email client built to replace Outlook and Webmail. It aggregates accounts from Exchange, Gmail, iCloud, and IMAP providers into a unified "Zero Inbox" experience. It runs locally, ensuring that email search is instant and offline access is robust.

## **2. Technical Architecture**

### **2.1 The Mail Engine**
*   **Libraries:** **go-imap** (Fetching) and **go-smtp** (Sending).
*   **Database:** Local SQLite/BadgerDB cache of headers and bodies for instant full-text search without server round-trips.

## **3. Core Features**

### **3.1 Unified Inbox**
*   **Aggregation:** View emails from multiple accounts in a single stream.
*   **Focus Mode:** AI-based filtering to separate "Important" mail from newsletters and notifications.

### **3.2 Productivity Tools**
*   **Snooze:** "Remind me later" functionality.
*   **Send Later:** Schedule emails to be sent at a specific time (held in local outbox or server-side if supported).
*   **Templates:** Canned responses for common inquiries.

### **3.3 Deep Integration**
*   **Ticket Conversion:** One-click "Convert to Ticket" (sends to SENTpilot).
*   **CRM Link:** Hovering over a sender shows their CRM profile from SENTorbit.

## **4. Integration with SENT Ecosystem**
*   **SENTcal:** Auto-detects meeting invites and adds them to the calendar.
*   **SENTvault:** Save attachments directly to secure document storage.

## **6. Expanded Integration Scenarios**
*   **SENTmission:** "Email to Task". Drag an email into a SENTmission project board to create a task, keeping the email thread attached for context.
*   **SENTchat:** "Discuss this Email". Share an email content to a chat channel for discussion without forwarding it.
*   **SENTshield:** "Phish Report". A big "Report Phishing" button analyzes the headers using SENTsignal and submits it to the security team.
*   **SENTcapital:** "Receipt Scan". Forward invoice emails to `receipts@sent` (or drag to SENTcapital tab) to auto-extract amount and date.

## **7. Future Feature Roadmap**
*   **AI Summary:** "TL;DR" button. Uses a local LLM to summarize long email threads into 3 bullet points.
*   **Read Receipts:** Pixel tracking to see when a recipient opens your email (if enabled/allowed).
*   **Undo Send:** 10-second buffer to recall an email after hitting send.
*   **Voice Dictation:** Native speech-to-text for composing emails.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Send and Receive email via IMAP/SMTP.
*   **In-Scope:**
    *   IMAP Sync (Download Headers/Body).
    *   SMTP Send (Plain text).
    *   Local Cache (SQLite).
    *   Basic UI (List view, Reader view).
    *   Attachments (Download/Upload).
*   **Out-of-Scope (Phase 2):**
    *   Unified Inbox (Single account only for MVP).
    *   Snooze / Send Later.
    *   HTML Composer.
    *   Search.