# **SENTstock – Inventory & Asset Management**

**Division:** SENTerp (Business)  
**Architecture:** Barcode/QR Engine (React-Zxing)  
**Status:** Operations

## **1. Executive Summary**
SENTstock manages physical goods. It tracks inventory levels, warehouse locations, and procurement. It is used by retailers to track products and by MSPs to track hardware stock (laptops, cables, servers).

## **2. Technical Architecture**

### **2.1 Scanning**
*   **Engine:** **React-Zxing** for browser-based barcode scanning via webcam.
*   **Support:** 1D Barcodes (UPC/EAN) and 2D Codes (QR, DataMatrix).

## **3. Core Features**

### **3.1 Warehouse Management**
*   **Bin Locations:** Tracks exact shelf location (Aisle 1, Shelf B, Bin 3).
*   **Transfers:** Movement between warehouses (Main -> Van 1).

### **3.2 Procurement**
*   **Reordering:** Auto-generates Purchase Orders (POs) when stock hits low-water mark.
*   **Vendor Catalog:** Import vendor price lists for comparison.

### **3.3 Asset Lifecycle**
*   **Serialized:** Tracking individual serial numbers for warranty purposes.

## **4. Integration with SENT Ecosystem**
*   **SENTkiosk:** Deducts inventory when a sale is made.
*   **SENTcapital:** Syncs inventory value to the Balance Sheet.

## **6. Expanded Integration Scenarios**
*   **SENTpilot:** "Parts Request". Technicians request a part (e.g., "Hard Drive") inside a ticket; Stock team approves and assigns the serial number.
*   **SENTmarket:** "Available to Sell". Syncs stock levels to the ecommerce store to prevent overselling.
*   **SENTnexus:** "Asset Birth". When a laptop is sold and scanned out, it automatically creates an Asset record in SENTnexus for the client.
*   **SENToptic:** "Shrinkage Cam". Flag timestamp of inventory adjustments to check security footage.

## **7. Future Feature Roadmap**
*   **RFID Support:** Bulk scanning of pallets using RFID readers.
*   **Mobile App:** Dedicated mobile app for warehouse pickers.
*   **Demand Forecasting:** AI predicts how much stock to order for the Christmas rush.
*   **Drop-Shipping:** Auto-route orders to vendors to ship directly to the client.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Track Items and Quantities.
*   **In-Scope:**
    *   Product Database (SKU, Name, Qty, Cost).
    *   Stock Adjustments (Add/Remove manually).
    *   Barcode Scanning (Webcam).
    *   Low Stock Alert.
*   **Out-of-Scope (Phase 2):**
    *   Purchase Orders.
    *   Multi-Warehouse.
    *   Serialized Inventory.
    *   Vendor Portals.