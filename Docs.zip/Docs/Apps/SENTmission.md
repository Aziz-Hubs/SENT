# **SENTmission – Project Management**

**Division:** SENTerp (Business)  
**Architecture:** Gantt/Kanban Engine (SVAR Gantt)  
**Status:** Operations

## **1. Executive Summary**
SENTmission manages the "Work in Progress" (WIP). It is a project management tool designed for professional services (e.g., MSP deployments, Software Development, Construction). It tracks time, budget, and milestones to ensure projects are profitable.

## **2. Technical Architecture**

### **2.1 The Visualizer**
*   **Engine:** **SVAR Gantt** (React component) for timeline rendering.
*   **Logic:** Critical Path Method (CPM) calculation in Go.

## **3. Core Features**

### **3.1 Planning**
*   **Gantt Charts:** Dependency linking (Task B cannot start until Task A finishes).
*   **Kanban Boards:** Drag-and-drop task movement for Agile workflows.

### **3.2 Resource Loading**
*   **Heatmap:** Visualizes employee workload ("Bob is 120% allocated next week").
*   **Budgeting:** Tracks "Planned vs Actual" hours and dollars.

### **3.3 Costing**
*   **WIP Accounting:** Calculates revenue recognition based on % complete.

## **4. Integration with SENT Ecosystem**
*   **SENTpilot:** Service tickets can be converted into project tasks.
*   **SENTcapital:** Generates milestone invoices automatically.

## **6. Expanded Integration Scenarios**
*   **SENTorbit:** "Sales to Project". Winning a deal in Orbit automatically spawns a project template (e.g., "New Client Onboarding") in Mission.
*   **SENTchat:** "Task Updates". Changes to tasks (Complete, Comment) are posted to the project's chat channel.
*   **SENTpeople:** "Skill Matching". When assigning a task (e.g., "Configure Cisco Router"), suggest employees who have the "CCNA" skill in their HR profile.
*   **SENTdrive:** Project files are stored in a dedicated SENTvault folder, accessible from the Mission UI.

## **7. Future Feature Roadmap**
*   **Portfolio Management:** High-level view of all projects across the company (PMO View).
*   **External Guest Access:** Allow clients to view the Gantt chart and comment on tasks (limited view).
*   **AI Scheduler:** "Optimize Schedule". Automatically rearranges tasks to minimize project duration based on resource availability.
*   **Risk Log:** Track risks and mitigation strategies per project.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Manage tasks and timelines.
*   **In-Scope:**
    *   Project Creation.
    *   Task List (Create/Edit/Delete).
    *   Kanban View.
    *   Basic Gantt (Start/End dates).
    *   Assignee selector.
*   **Out-of-Scope (Phase 2):**
    *   Resource Heatmaps.
    *   Budgeting/Costing.
    *   WIP Accounting.
    *   Dependencies (Critical Path).