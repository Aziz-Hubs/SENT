# **SENTcapital – Finance & Accounting**

**Division:** SENTerp (Business)  
**Architecture:** Double-Entry Ledger (Shopspring/Decimal)  
**Status:** Finance

## **1. Executive Summary**
SENTcapital is the source of financial truth. It is a double-entry accounting system that handles General Ledger (GL), Accounts Payable (AP), Accounts Receivable (AR), and Banking. It replaces QuickBooks or Xero.

## **2. Technical Architecture**

### **2.1 The Math**
*   **Precision:** Uses fixed-point arithmetic (Go `shopspring/decimal` library) to ensure zero rounding errors.
*   **Integrity:** Immutable ledger entries – transactions cannot be deleted, only reversed.

## **3. Core Features**

### **3.1 Core Accounting**
*   **Multi-Currency:** Live exchange rate syncing.
*   **Bank Feeds:** Plaid / Yodlee integration for pulling transactions.
*   **Reconciliation:** AI-assisted matching of bank lines to ledger entries.

### **3.2 Automation**
*   **Recurring Invoices:** Automated billing for subscriptions.
*   **Dunning:** Automated follow-up emails for overdue invoices.

### **3.3 Reporting**
*   **Standard:** P&L, Balance Sheet, Cash Flow Statement.
*   **Dimensions:** Tag transactions by Department, Location, or Project.

## **4. Integration with SENT Ecosystem**
*   **SENTpilot:** Syncs billable hours.
*   **SENTbridge:** Pushes data to government tax authorities.
*   **SENTpeople:** Post payroll journals.

## **6. Expanded Integration Scenarios**
*   **SENTstock:** "COGS Calculation". Sold inventory automatically credits Inventory Asset and debits Cost of Goods Sold.
*   **SENTmarket:** "Automatic Payment". Orders on the B2B store create a "Paid" invoice/receipt in Capital instantly.
*   **SENTcontrol:** "Subscription Mapping". Links a vendor invoice (e.g., from Microsoft) to the specific SaaS licenses tracked in Control to verify accuracy.
*   **SENTdeck:** "Investor Update". Exports financial charts directly to an investor slide deck.

## **7. Future Feature Roadmap**
*   **Cash Flow Forecasting:** Predictive AI analyzes past trends to predict run-out dates.
*   **Expense Management:** Mobile app for employees to photograph receipts and submit expense reports.
*   **Consolidation:** Combine books from multiple subsidiary companies into a Group Report.
*   **Fixed Asset Register:** Track depreciation of heavy machinery/laptops over time.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Record Transactions and produce a Balance Sheet.
*   **In-Scope:**
    *   Chart of Accounts (Standard Template).
    *   Journal Entry Interface.
    *   Invoicing (Create PDF).
    *   Basic Reporting (Trial Balance, P&L).
    *   Bank Manual Import (CSV).
*   **Out-of-Scope (Phase 2):**
    *   Bank API Feeds.
    *   Multi-Currency.
    *   Recurring Invoices.
    *   Fixed Assets.