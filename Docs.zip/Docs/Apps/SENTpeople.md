# **SENTpeople – HR & Payroll**

**Division:** SENTerp (Business)  
**Architecture:** HRIS Engine  
**Status:** People Operations

## **1. Executive Summary**
SENTpeople is the Human Resources Information System (HRIS). It manages the employee lifecycle from "Hire to Retire". It handles org charts, time off, performance reviews, and payroll processing.

## **2. Technical Architecture**

### **2.1 Security**
*   **Encryption:** PII (Personally Identifiable Information) like Social Security Numbers and Bank Details are encrypted at rest using AES-GCM.

## **3. Core Features**

### **3.1 Core HR**
*   **Directory:** Searchable employee list.
*   **Org Chart:** Visual hierarchy tree.
*   **Onboarding:** Checklist for new hires (Sign contract, Watch training, Pick laptop).

### **3.2 Time & Attendance**
*   **Leave:** Vacation/Sick day requests and approvals.
*   **Clock:** Geo-fenced clock-in/clock-out for hourly staff.

### **3.3 Payroll**
*   **Processing:** Calculation of Gross-to-Net pay, tax deductions, and benefits.
*   **Payslips:** PDF payslip generation and email delivery.

## **4. Integration with SENT Ecosystem**
*   **SENTcontrol:** Auto-provisions accounts when a new user is added.
*   **SENTcapital:** Posts payroll expenses to the ledger.
*   **SENTmind:** Enrolls new hires in security training.

## **6. Expanded Integration Scenarios**
*   **SENTaccess:** "Alumni Portal". Terminated employees retain limited access to download past payslips and tax forms.
*   **SENTmission:** "Capacity Planning". Blocks project assignment if the user has approved leave during the project dates.
*   **SENTpilot:** "Ticket Routing". Tickets from the CEO are flagged as VIP because of their role in the Org Chart.
*   **SENTwave:** "Emergency Blast". Uses employee cell phone numbers to send SMS alerts during a crisis.

## **7. Future Feature Roadmap**
*   **360 Reviews:** Peer-to-peer performance feedback collection.
*   **Benefits Administration:** Portal for employees to choose health insurance plans.
*   **Applicant Tracking System (ATS):** Manage job postings and resumes before they become employees.
*   **Sentiment Pulse:** Weekly 1-question survey ("How happy are you?") to track morale.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Employee Database and Leave Tracking.
*   **In-Scope:**
    *   Employee Profiles (Name, Role, Salary).
    *   Document Storage (Contracts).
    *   Leave Request Workflow (Request -> Approve).
    *   Org Chart Visualizer.
*   **Out-of-Scope (Phase 2):**
    *   Payroll Processing (Calculator).
    *   Time Clocks.
    *   Performance Reviews.
    *   Onboarding Checklists.