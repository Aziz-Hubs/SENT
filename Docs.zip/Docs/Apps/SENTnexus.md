# **SENTnexus – IT Documentation & Knowledge Base**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** Graph Database / Wiki (Ent Graph + Zitadel Vault)  
**Status:** Core Knowledge Store

## **1. Executive Summary**
SENTnexus is the "Brain" of the IT operation. It is a structured documentation platform designed to eliminate tribal knowledge. Unlike static wikis, SENTnexus is a dynamic "living" system where documentation is updated automatically by the RMM (SENTpulse) and linked deeply to the ticketing system (SENTpilot). It handles secure credential storage, network mapping, and standard operating procedures (SOPs).

## **2. Technical Architecture**

### **2.1 The Data Structure**
*   **Graph Model:** Utilizes **Ent**'s graph capabilities to map complex dependencies (e.g., "Server A" *hosts* "Virtual Machine B" *which runs* "SQL Database C").
*   **Security:** Field-level encryption for sensitive data (passwords, API keys) using AES-256.

### **2.2 The Security Vault**
*   **Integration:** Deep integration with **Zitadel** for access control.
*   **Audit:** "Break Glass" logging – every time a password is viewed, it is logged with a timestamp and user ID.

## **3. Core Features**

### **3.1 Flexible Asset Management**
*   **Custom Types:** Define any asset class (e.g., SSL Certificates, Domain Names, Key Cards, Vendor Contacts).
*   **Auto-Documentation:** Syncs with SENTpulse to keep fields like "OS Version", "IP Address", and "Serial Number" up to date without human intervention.

### **3.2 Password Management**
*   **Organization:** Hierarchical password storage (Client -> Site -> Device).
*   **Sharing:** Secure, temporary "One-Time Links" for sharing credentials with external vendors or clients.
*   **Masking:** Passwords are masked by default and require an explicit "Reveal" click (which is audited).

### **3.3 Relationship Mapping**
*   **Visualizer:** Interactive node-graph visualization of network dependencies.
*   **Impact Analysis:** Clicking a "Switch" node shows all downstream devices and users that would be affected by an outage.

### **3.4 Knowledge Base (SOPs)**
*   **Editor:** Markdown-based editor with support for diagrams (Mermaid.js).
*   **Linking:** `@mention` assets directly within articles (e.g., "To restart the @Firewall, login with @FirewallAdmin").

## **4. Integration with SENT Ecosystem**
*   **SENTpilot:** Technicians see relevant passwords and SOPs side-by-side with tickets.
*   **SENTpulse:** Provides the raw data to populate asset fields.
*   **SENTguard:** links security incidents to specific asset documentation.

## **6. Expanded Integration Scenarios**
*   **SENTcontrol (SaaS):** Automatically creates "Domain Asset" pages for every domain found in the SaaS manager, including DNS record documentation.
*   **SENTprobe (Vuln Scanner):** Enhances asset pages with a "Vulnerability Tab" listing open CVEs found on that specific device.
*   **SENTpeople (HR):** Links "Offboarding SOPs" to the specific asset types assigned to a departing employee (e.g., "MacBook Offboarding Guide" vs "ThinkPad Offboarding Guide").
*   **SENTgrid (Network):** Imports switch configurations and auto-maps which wall jack (Port) connects to which desk (Asset).

## **7. Future Feature Roadmap**
*   **Browser Extension:** A Chrome/Edge extension that detects when you visit a login page (e.g., `router-login.com`) and offers to autofill credentials from SENTnexus.
*   **Expiry Notifications:** Automated emails for expiring assets (SSL Certs, Domains, Contracts) 30, 60, and 90 days out.
*   **Diagram Builder:** Drag-and-drop network topology builder that syncs changes back to the asset database.
*   **"Runbook" Execution:** Executable code blocks within documentation. Click "Run" in the SOP to execute the command via SENTpulse.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Store Passwords and Static Asset Lists securely.
*   **In-Scope:**
    *   Asset List View (Create/Read/Update/Delete).
    *   Password Vault (Encrypted storage, Copy to Clipboard).
    *   Basic Wiki Pages (Markdown text).
    *   Global Search.
*   **Out-of-Scope (Phase 2):**
    *   Visual Relationship Graph.
    *   Automated Sync with SENTpulse.
    *   Browser Extension.
    *   OTP/2FA Code Generator.