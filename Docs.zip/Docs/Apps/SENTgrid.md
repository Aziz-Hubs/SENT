# **SENTgrid – Network Management & Automation**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** SSH Worker Pool / Netconf  
**Status:** Network Infrastructure

## **1. Executive Summary**
SENTgrid is the specialized tool for network engineers. It moves beyond simple up/down monitoring (handled by SENTpulse) to provide deep configuration management, backup, and automation for network appliances like switches, routers, and firewalls (Cisco, Fortinet, Ubiquiti, Juniper).

## **2. Technical Architecture**

### **2.1 The Worker Pool**
*   **Engine:** Dedicated Go routines handling SSH and Telnet sessions.
*   **Parsing:** Utilizes "TextFSM" style templates (Google's textfsm or Go equivalents) to parse unstructured CLI output into structured JSON.

### **2.2 Protocol Support**
*   **Protocols:** SSHv2, Telnet (legacy), SNMP v2/v3, NETCONF.

## **3. Core Features**

### **3.1 Configuration Management**
*   **Backup:** Automated nightly backup of running-config and startup-config.
*   **Diffing:** Visual side-by-side comparison of configuration changes over time (e.g., "Show me what changed since last night").
*   **Drift Detection:** Alerts if the live configuration deviates from the "Golden Image" or standard template.

### **3.2 Topology Mapping**
*   **Discovery:** LLDP and CDP neighbor discovery to automatically map physical port connections.
*   **Visualization:** dynamic Layer 2/Layer 3 network maps.

### **3.3 Port Management**
*   **Switch Commander:** A GUI to search for a MAC address, find the switch port, and execute commands (Shut/No Shut, Change VLAN) without learning CLI syntax for every vendor.
*   **PoE Control:** Remote power cycling of PoE ports to reboot attached devices (Phones, APs, Cameras).

### **3.4 Firmware Management**
*   **Repository:** Central store for firmware images.
*   **Deployment:** Bulk firmware upgrade scheduler.

## **4. Integration with SENT Ecosystem**
*   **SENTpulse:** Alerts on high bandwidth usage or packet errors.
*   **SENTnexus:** Updates documentation with VLAN configs, IP routes, and switch stack members.
*   **SENTpilot:** Tickets created for failed backups or configuration drift.

## **6. Expanded Integration Scenarios**
*   **SENTreflex (SOAR):** "Quarantine Port". If a device is infected, Reflex commands SENTgrid to flip the switch port to a "Quarantine VLAN".
*   **SENTwave (VoIP):** "QoS Enforcer". SENTgrid automatically detects SIP traffic and auto-configures QoS priority tagging on switches.
*   **SENTstock:** "RMA Processor". If a switch fails, SENTgrid pulls the "RMA Procedure" from the vendor file and updates the inventory status to "Defective".
*   **SENTsonar:** Correlates "NetFlow" spikes seen in SENTsonar with the specific switch interface in SENTgrid.

## **7. Future Feature Roadmap**
*   **Zero Touch Provisioning (ZTP):** DHCP server integration to auto-provision new switches out of the box.
*   **Wifi Heatmapping:** Import floor plans and signal strength data to visualize WiFi coverage.
*   **Compliance Audits:** Auto-check configs against DISA STIGs or CIS Benchmarks (e.g., "Ensure Telnet is disabled").
*   **Optical Monitoring:** Monitor fiber light levels (dBm) to predict SFP failure.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Backup configuration of SSH-enabled network devices.
*   **In-Scope:**
    *   SSH Credential Management.
    *   Job Scheduler (Daily Backup).
    *   Basic Expect script (Login, `show run`, Logout).
    *   Text File Storage of Configs.
    *   Simple Diff Viewer.
*   **Out-of-Scope (Phase 2):**
    *   Change/Push Configuration.
    *   Topology Mapping.
    *   SNMP Traps.
    *   PoE Control.