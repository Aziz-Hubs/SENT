# **SENTkiosk – Point of Sale (POS)**

**Division:** SENTerp (Business)  
**Architecture:** Touch Interface  
**Status:** Retail

## **1. Executive Summary**
SENTkiosk brings SENT to the physical counter. It is a touch-optimized Point of Sale interface for retail environments. It handles rapid scanning, cash management, and receipt printing.

## **2. Technical Architecture**

### **2.1 Hardware Support**
*   **Peripherals:** Integration with Receipt Printers (ESC/POS), Cash Drawers, and Barcode Scanners via Serial/USB.

## **3. Core Features**

### **3.1 Checkout**
*   **Speed:** Optimized for minimal clicks.
*   **Payments:** Integration with Card Terminals.

### **3.2 Cash Management**
*   **Shift:** Track cash float, lifts, and drops.
*   **X/Z Reports:** End-of-day reconciliation.

## **4. Integration with SENT Ecosystem**
*   **SENTstock:** Instant inventory deduction.
*   **SENTcapital:** Daily sales synced to the General Ledger.
*   **SENTorbit:** Loyalty program tracking (attach sale to customer).

## **6. Expanded Integration Scenarios**
*   **SENTpeople:** "Time Clock". Employees clock in for their shift directly on the POS screen.
*   **SENToptic:** "Loss Prevention". POS bookmarks the video feed every time the "No Sale" (Open Drawer) button is pressed.
*   **SENTaccess:** "Digital Receipt". Ask customer for email/phone; receipt is sent to their SENTaccess portal history.
*   **SENTmission:** "Service Desk". Use the POS to book a repair job (Service Ticket) instead of a product sale.

## **7. Future Feature Roadmap**
*   **Self-Checkout Mode:** UI flips to a customer-facing mode for self-service.
*   **Kitchen Display System (KDS):** If used in a cafe, orders send to a screen in the kitchen.
*   **Offline Mode:** Continue selling if internet drops; sync later.
*   **Scale Integration:** Weigh produce/items at the counter.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Process a cash sale.
*   **In-Scope:**
    *   Product Button Grid.
    *   Barcode Lookup.
    *   Cart (Add/Remove).
    *   Cash Tender.
    *   Receipt Print.
*   **Out-of-Scope (Phase 2):**
    *   Card Terminal Integration.
    *   Customer Accounts.
    *   Returns/Exchanges.
    *   Shift Management.