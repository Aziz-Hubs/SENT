# **SENTpilot – Professional Services Automation (PSA)**

**Division:** SENTmsp (Infrastructure)  
**Architecture:** Workflow Engine (Ent + React)  
**Status:** Core Business Logic

## **1. Executive Summary**
SENTpilot is the operational cockpit for IT providers and managed service teams. It unifies ticketing, billing, and project management into a single "Context-Aware" application. By tightly integrating with SENTpulse, SENTpilot eliminates the "swivel-chair" effect, allowing technicians to solve problems directly from the ticket interface without switching tools.

## **2. Technical Architecture**

### **2.1 The Engine**
*   **Backend:** Go (Golang) with **Ent** (Entity Framework) for complex relationship mapping (Ticket -> Client -> Device -> Contract).
*   **Search:** Full-text search optimized for error codes and historical ticket resolutions.

### **2.2 The Interface**
*   **Framework:** React 19 + Wails v2.
*   **UX Pattern:** "Single Pane of Glass" – Ticket details on the left, live device telemetry (via SENTpulse) on the right.

## **3. Core Features**

### **3.1 Context-Aware Ticketing**
*   **Smart Attachments:** When a user submits a ticket from their device via the SENT agent, SENTpilot automatically attaches the device's recent event logs, screenshot, and performance history.
*   **Deduplication:** AI-driven merging of similar tickets (e.g., 50 users reporting "Internet Down" becomes 1 Master Ticket).

### **3.2 Automated Billing & Contracts**
*   **Time Tracking:** "Stopwatch" style time entry for technicians, automatically associated with the open ticket.
*   **Contract Logic:** Support for Retainers, Block Hours, and Managed Services (Flat Rate).
*   **Invoicing:** Auto-generates invoices based on time entries and hardware procurement, integrated with SENTcapital.

### **3.3 Service Level Agreement (SLA) Management**
*   **Countdown Timers:** Visual urgency indicators for "Response Time" and "Resolution Time".
*   **Escalation Workflows:** Automatic notification of managers if a VIP client's ticket breaches 50% of the SLA window.

### **3.4 Client Portal Integration**
*   Allows end-users to view ticket status, approve quotes, and chat with technicians via **SENTaccess**.

## **4. Data Strategy**
*   **Relational Data:** Strictly typed PostgreSQL schema managed by Ent.
*   **Audit Trail:** Immutable log of every action taken on a ticket (who changed what and when).

## **5. Integration with SENT Ecosystem**
*   **SENTpulse:** One-click remote control initiation directly from the ticket view.
*   **SENTnexus:** Automatic linking of "ConfigItems" (Assets) to tickets for historical tracking.
*   **SENTcapital:** Seamless sync of approved invoices and billable hours.

## **6. Expanded Integration Scenarios**
*   **SENTchat (Messaging):** "Chat-to-Ticket" workflow. Right-click a message in SENTchat and select "Create Ticket". Updates on the ticket are posted back to a thread in the chat.
*   **SENTcal (Scheduling):** "Dispatch View". Drag-and-drop tickets onto a technician's calendar in SENTcal to schedule an on-site visit.
*   **SENTwave (VoIP):** Incoming calls match the caller ID to a user in SENTpilot. The ticket history pops up before the call is answered.
*   **SENTshield (GRC):** When a ticket related to "Access Rights" is closed, it automatically logs as evidence for ISO 27001 Access Control audits.

## **7. Future Feature Roadmap**
*   **Sentiment Analysis:** Analyze ticket text using NLP to gauge user frustration (Angry/Neutral/Happy) and prioritize "Angry" tickets.
*   **Skills-Based Routing:** Auto-assign tickets based on tags (e.g., "Firewall" tag -> Assigns to Network Engineer).
*   **Gamification:** Leaderboards for technicians (Most Tickets Closed, Best CSAT Score).
*   **"Uber-style" Technician Tracking:** For on-site visits, send the client a map link showing the technician's location en route.

## **8. Minimum Viable Product (MVP) Scope**
*   **Core Goal:** Create, Track, and Close a support ticket.
*   **In-Scope:**
    *   Ticket Board (Kanban view: New, In Progress, Closed).
    *   Ticket Creation Form (Subject, Description, Priority).
    *   Client/User Database (Basic CRUD).
    *   Internal Notes vs. Public Replies.
    *   Basic Email Notification (New Ticket / Closed Ticket).
*   **Out-of-Scope (Phase 2):**
    *   SLA Timers.
    *   Time Tracking / Billing Integration.
    *   Customer Portal.
    *   Automated Workflow Rules.