# **SENT LLC \- Master Service Portfolio**

**Version:** 4.1 (Detailed Catalog)

**Architecture:** Unified Modular Monolith (Native Desktop)

## **1\. SENTmsp (Infrastructure Division)**

**Theme:** Visibility, Control, and Connection.

### **SENTpulse (Remote Monitoring & Management)**

* **Core Function:** Real-time health monitoring of servers and workstations.  
* **Key Features:**  
  * Silent background agent (Go-Sysinfo) with \<1% CPU usage.  
  * Automated self-healing scripts (e.g., restart service if RAM \> 90%).  
  * Live hardware telemetry (Temp, Fan Speed, Disk Health).  
* **Tech Engine:** Go-Sysinfo \+ Wails (Agent UI).

### **SENTpilot (Professional Services Automation)**

* **Core Function:** Intelligent ticketing and helpdesk management.  
* **Key Features:**  
  * "Context-Aware" Tickets: When a user submits a ticket, the system attaches their device logs automatically.  
  * SLA countdown timers with escalation workflows.  
  * Automated billing based on time-entry.  
* **Business Value:** Reduces "Ping-Pong" support conversations by 40%.

### **SENTnexus (IT Documentation)**

* **Core Function:** The "Brain" of the IT department (Wiki/Knowledge Base).  
* **Key Features:**  
  * Structured asset documentation linked to live RMM data.  
  * Password/Credential mapping (masked & encrypted).  
  * Relationship mapping (Server A hosts App B).  
* **Business Value:** Eliminates tribal knowledge; makes technician onboarding instant.

### **SENThorizon (vCIO & Strategy)**

* **Core Function:** Strategic IT planning and lifecycle management.  
* **Key Features:**  
  * Hardware warranty tracking and refresh budgeting.  
  * QBR (Quarterly Business Review) report generator.  
  * IT Roadmap visualization.

### **SENTcontrol (SaaS Management)**

* **Core Function:** Management of cloud subscriptions (M365, Workspace).  
* **Key Features:**  
  * API integration with Microsoft Graph & Google Admin.  
  * License usage auditing (find unused licenses).  
  * User onboarding/offboarding workflows.

### **SENToptic (CCTV Surveillance)**

* **Core Function:** Network Video Recorder (NVR) and streaming.  
* **Key Features:**  
  * RTSP streaming directly to the desktop app.  
  * Motion event timeline.  
  * Vendor agnostic (Works with Hikvision, Dahua, Axis).  
* **Tech Engine:** MediaMTX.

## **2\. SENTsec (Security Division)**

**Theme:** Defense, Detection, and Reflex.

### **SENTradar (SIEM & Log Analysis)**

* **Core Function:** Centralized log aggregation and threat detection.  
* **Key Features:**  
  * Ingests logs from Windows Event Viewer, Syslog, and Firewalls.  
  * Real-time Sigma rule matching for anomaly detection.  
  * Forensic timeline search.  
* **Tech Engine:** Expr \+ Sigma (Isolated Worker Mode).

### **SENTguard (Endpoint Detection & Response)**

* **Core Function:** Active endpoint protection and threat hunting.  
* **Key Features:**  
  * Process killing and network isolation for infected hosts.  
  * File integrity monitoring.  
  * Ransomware canary files.  
* **Tech Engine:** Gopacket (Packet Capture).

### **SENTshield (GRC & Compliance)**

* **Core Function:** Automated governance, risk, and compliance reporting.  
* **Key Features:**  
  * One-click ISO 27001 / GDPR gap analysis.  
  * Automated PDF report generation.  
  * Vendor risk assessment questionnaires.  
* **Tech Engine:** Maroto (PDF Generation).

### **SENTmind (Phishing Simulation)**

* **Core Function:** Employee security awareness training.  
* **Key Features:**  
  * Simulated phishing email campaigns.  
  * "Teachable Moments" landing pages for failed tests.  
  * Training progress tracking.  
* **Tech Engine:** Gophish (Architecture Reference).

### **SENTprobe (Vulnerability Scanner)**

* **Core Function:** Continuous identification of network weaknesses.  
* **Key Features:**  
  * External IP scanning (Ports, CVEs).  
  * Internal network scanning (Weak passwords, unpatched OS).  
  * Automated remediation ticket creation.  
* **Tech Engine:** Nuclei.

## **3\. SENTerp (Business Division)**

**Theme:** Efficiency, Flow, and Truth.

### **Productivity Suite**

* **SENTmail:** Native IMAP/SMTP client with unified inbox and deep search. (Go-IMAP)  
* **SENTchat:** Corporate messaging with channels, threads, and file sharing. (Centrifugo)  
* **SENTmeet:** HD Video conferencing with screen sharing and recording. (Pion WebRTC)  
* **SENTsheet:** Full-featured spreadsheet editor compatible with .xlsx. (Univer)  
* **SENTscribe:** Collaborative rich-text document editor (Wiki/SOPs).  
* **SENTdeck:** Slide presentation builder and presenter.

### **Business Operations**

* **SENTcapital (Finance):** Multi-currency general ledger, AP/AR, and automated bank reconciliation. (Shopspring/Decimal)  
* **SENTorbit (CRM):** Sales pipeline management, lead scoring, and contact enrichment.  
* **SENTmission (Projects):** Project management with Gantt charts, Kanban boards, and resource loading. (SVAR Gantt)  
* **SENTpeople (HR):** Employee directory, leave management, org charts, and payroll processing.  
* **SENTstock (Inventory):** Barcode-based asset tracking, stock levels, and procurement. (React-Zxing)  
* **SENTbridge (GovTech):** Integration with JoFotara/Government tax gateways for compliant invoicing. (Go XML)  
* **SENTvault (DMS):** Secure file storage with version control and permission management. (Afero)  
* **SENTmarket:** E-commerce storefront generator for B2B client ordering.